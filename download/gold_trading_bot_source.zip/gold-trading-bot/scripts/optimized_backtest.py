"""
OPTIMIZED High-Performance Backtest
Fine-tuned for maximum returns with small capital ($50)
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Tuple
from dataclasses import dataclass
import logging

logging.basicConfig(level=logging.INFO, format='%(message)s')
logger = logging.getLogger(__name__)


@dataclass
class Trade:
    entry_time: datetime
    exit_time: datetime
    direction: str
    entry_price: float
    exit_price: float
    position_size: float
    pnl: float
    result: str
    exit_reason: str


class OptimizedBacktest:
    """
    Optimized trading strategy for maximum returns.
    
    Key optimizations:
    1. Tight take profit (quick wins)
    2. Far stop loss (rarely hit)
    3. Aggressive partial profit taking
    4. High probability entries only
    5. Compound position sizing
    """
    
    def __init__(self, initial_capital: float = 50.0, leverage: int = 500):
        self.initial_capital = initial_capital
        self.capital = initial_capital
        self.leverage = leverage
        
        # OPTIMIZED PARAMETERS
        self.tp_pips = 6          # Tight TP for high win rate
        self.sl_pips = 18         # Far SL (3:1 ratio)
        self.risk_per_trade = 0.05  # 5% risk
        self.win_rate_target = 0.78  # Target 78% win rate
        
        # Dynamic profit management
        self.partial_close_pct = 0.5   # Close 50% early
        self.partial_at_pips = 4       # At 4 pips profit
        self.breakeven_after_partial = True
        
        # Risk limits
        self.max_daily_loss = 0.15     # 15% daily max loss
        self.max_daily_trades = 12
        
        # Session optimization (best hours for gold)
        self.best_hours = [8, 9, 10, 13, 14, 15, 16]  # London/NY overlap
        
    def generate_market_data(self, days: int) -> pd.DataFrame:
        """Generate realistic gold price data."""
        np.random.seed(42)
        
        candles_per_day = 96  # 15-minute candles
        total_candles = days * candles_per_day
        
        dates = pd.date_range(end=datetime.now(), periods=total_candles, freq='15min')
        
        # Generate price with trend and noise
        prices = []
        price = 2000.0
        trend = 0.0
        trend_duration = 0
        
        for i in range(total_candles):
            # Trend changes
            if trend_duration <= 0:
                trend = np.random.uniform(-0.4, 0.4)
                trend_duration = np.random.randint(30, 100)
            
            # Random component
            noise = np.random.normal(0, 1.0)
            
            # Jump component (news)
            jump = 0
            if np.random.random() < 0.02:
                jump = np.random.choice([-6, -4, 4, 6])
            
            price += trend + noise + jump
            price = max(1900, min(2100, price))
            prices.append(price)
            
            trend_duration -= 1
        
        # Create OHLC
        ohlc = []
        for i, price in enumerate(prices):
            spread = np.random.uniform(0.3, 1.5)
            ohlc.append({
                'time': dates[i],
                'open': price + np.random.uniform(-0.3, 0.3),
                'high': price + spread,
                'low': price - spread,
                'close': price,
                'volume': np.random.randint(100, 1500),
                'hour': dates[i].hour
            })
        
        return pd.DataFrame(ohlc)
    
    def calculate_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """Calculate technical indicators."""
        df = df.copy()
        
        # EMAs
        df['ema_5'] = df['close'].ewm(span=5).mean()
        df['ema_13'] = df['close'].ewm(span=13).mean()
        df['ema_34'] = df['close'].ewm(span=34).mean()
        
        # RSI
        delta = df['close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(7).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(7).mean()
        rs = gain / loss
        df['rsi'] = 100 - (100 / (1 + rs))
        
        # MACD
        df['macd'] = df['close'].ewm(span=12).mean() - df['close'].ewm(span=26).mean()
        df['macd_signal'] = df['macd'].ewm(span=9).mean()
        df['macd_hist'] = df['macd'] - df['macd_signal']
        
        # Bollinger
        df['bb_mid'] = df['close'].rolling(20).mean()
        df['bb_std'] = df['close'].rolling(20).std()
        df['bb_upper'] = df['bb_mid'] + 2 * df['bb_std']
        df['bb_lower'] = df['bb_mid'] - 2 * df['bb_std']
        df['bb_pos'] = (df['close'] - df['bb_lower']) / (df['bb_upper'] - df['bb_lower'])
        
        # Stochastic
        low_min = df['low'].rolling(14).min()
        high_max = df['high'].rolling(14).max()
        df['stoch_k'] = 100 * (df['close'] - low_min) / (high_max - low_min)
        df['stoch_d'] = df['stoch_k'].rolling(3).mean()
        
        # ATR
        tr = pd.concat([
            df['high'] - df['low'],
            abs(df['high'] - df['close'].shift()),
            abs(df['low'] - df['close'].shift())
        ], axis=1).max(axis=1)
        df['atr'] = tr.rolling(14).mean()
        
        # Momentum
        df['mom'] = df['close'] - df['close'].shift(5)
        
        # Trend
        df['trend_up'] = (df['ema_5'] > df['ema_13']) & (df['ema_13'] > df['ema_34'])
        df['trend_down'] = (df['ema_5'] < df['ema_13']) & (df['ema_13'] < df['ema_34'])
        
        return df
    
    def check_entry(self, df: pd.DataFrame, idx: int) -> Tuple[str, float]:
        """Check for high probability entry."""
        row = df.iloc[idx]
        prev = df.iloc[idx - 1]
        
        score = 0.0
        direction = None
        
        # Check trading hours
        if row['hour'] not in self.best_hours:
            return None, 0.0
        
        # BULLISH conditions
        bullish_score = 0.0
        if row['trend_up']:
            bullish_score += 0.25
        if row['rsi'] < 40:
            bullish_score += 0.20
        if row['stoch_k'] < 30 and row['stoch_k'] > prev['stoch_k']:
            bullish_score += 0.20
        if row['macd_hist'] > 0:
            bullish_score += 0.15
        if row['bb_pos'] < 0.3:
            bullish_score += 0.10
        if row['mom'] > 0:
            bullish_score += 0.10
        
        # BEARISH conditions
        bearish_score = 0.0
        if row['trend_down']:
            bearish_score += 0.25
        if row['rsi'] > 60:
            bearish_score += 0.20
        if row['stoch_k'] > 70 and row['stoch_k'] < prev['stoch_k']:
            bearish_score += 0.20
        if row['macd_hist'] < 0:
            bearish_score += 0.15
        if row['bb_pos'] > 0.7:
            bearish_score += 0.10
        if row['mom'] < 0:
            bearish_score += 0.10
        
        # Choose direction with highest score
        if bullish_score >= 0.55:
            return 'BUY', bullish_score
        elif bearish_score >= 0.55:
            return 'SELL', bearish_score
        
        return None, 0.0
    
    def run_backtest(self, days: int = 90) -> Dict:
        """Run optimized backtest."""
        logger.info(f"Running OPTIMIZED backtest: {days} days, ${self.initial_capital} capital")
        
        # Generate data
        df = self.generate_market_data(days)
        df = self.calculate_indicators(df)
        
        # Trading simulation
        capital = self.initial_capital
        trades: List[Trade] = []
        daily_pnl = {}
        daily_trades = {}
        open_positions = []
        
        pip = 0.01
        pip_value = 0.10  # $0.10 per pip for 0.01 lot
        
        for i in range(50, len(df)):
            row = df.iloc[i]
            current_date = row['time'].strftime('%Y-%m-%d')
            current_price = row['close']
            current_hour = row['hour']
            
            # Initialize daily tracking
            if current_date not in daily_pnl:
                daily_pnl[current_date] = 0.0
                daily_trades[current_date] = 0
            
            # Check daily loss limit
            if daily_pnl[current_date] < -capital * self.max_daily_loss:
                continue
            
            # Manage open positions
            for pos in open_positions[:]:
                # Calculate current profit
                if pos['direction'] == 'BUY':
                    profit_pips = (current_price - pos['entry']) / pip
                else:
                    profit_pips = (pos['entry'] - current_price) / pip
                
                # Take profit hit
                if profit_pips >= pos['tp']:
                    pnl = profit_pips * pip_value * pos['size'] / 0.01
                    capital += pnl
                    daily_pnl[current_date] += pnl
                    
                    trades.append(Trade(
                        entry_time=pos['time'],
                        exit_time=row['time'],
                        direction=pos['direction'],
                        entry_price=pos['entry'],
                        exit_price=current_price,
                        position_size=pos['original_size'],
                        pnl=pnl,
                        result='WIN',
                        exit_reason='TP'
                    ))
                    open_positions.remove(pos)
                    continue
                
                # Stop loss hit
                if profit_pips <= -pos['sl']:
                    pnl = -pos['sl'] * pip_value * pos['size'] / 0.01
                    capital += pnl
                    daily_pnl[current_date] += pnl
                    
                    trades.append(Trade(
                        entry_time=pos['time'],
                        exit_time=row['time'],
                        direction=pos['direction'],
                        entry_price=pos['entry'],
                        exit_price=current_price,
                        position_size=pos['original_size'],
                        pnl=pnl,
                        result='LOSS',
                        exit_reason='SL'
                    ))
                    open_positions.remove(pos)
                    continue
                
                # Partial close at profit
                if profit_pips >= self.partial_at_pips and not pos.get('partial'):
                    partial_pnl = profit_pips * pip_value * pos['size'] * self.partial_close_pct / 0.01
                    capital += partial_pnl
                    daily_pnl[current_date] += partial_pnl
                    pos['size'] *= (1 - self.partial_close_pct)
                    pos['partial'] = True
                    
                    # Move to breakeven
                    if self.breakeven_after_partial:
                        pos['sl'] = 0  # Now at breakeven
            
            # Check for new entries
            if len(open_positions) < 2 and daily_trades[current_date] < self.max_daily_trades:
                if current_hour in self.best_hours:
                    direction, score = self.check_entry(df, i)
                    
                    if direction and score >= 0.55:
                        # Calculate position size
                        risk_amount = capital * self.risk_per_trade
                        position_size = risk_amount / (self.sl_pips * pip_value)
                        position_size = max(0.01, min(0.20, round(position_size, 2)))
                        
                        entry = current_price
                        if direction == 'BUY':
                            sl_pips = self.sl_pips
                            tp_pips = self.tp_pips
                        else:
                            sl_pips = self.sl_pips
                            tp_pips = self.tp_pips
                        
                        open_positions.append({
                            'time': row['time'],
                            'entry': entry,
                            'direction': direction,
                            'sl': sl_pips,
                            'tp': tp_pips,
                            'size': position_size,
                            'original_size': position_size,
                            'partial': False
                        })
                        
                        daily_trades[current_date] += 1
        
        # Calculate final statistics
        wins = [t for t in trades if t.result == 'WIN']
        losses = [t for t in trades if t.result == 'LOSS']
        
        total_trades = len(trades)
        winning_trades = len(wins)
        losing_trades = len(losses)
        win_rate = (winning_trades / total_trades * 100) if total_trades > 0 else 0
        
        total_profit = capital - self.initial_capital
        growth_percent = (total_profit / self.initial_capital) * 100
        
        total_won = sum(t.pnl for t in wins)
        total_lost = abs(sum(t.pnl for t in losses))
        profit_factor = total_won / total_lost if total_lost > 0 else float('inf')
        
        # Daily stats
        profitable_days = sum(1 for p in daily_pnl.values() if p > 0)
        losing_days = sum(1 for p in daily_pnl.values() if p < 0)
        total_days = len(daily_pnl)
        daily_win_rate = (profitable_days / total_days * 100) if total_days > 0 else 0
        
        # Weekly analysis
        sorted_dates = sorted(daily_pnl.keys())
        weekly_returns = []
        for i in range(0, len(sorted_dates), 7):
            week_pnl = sum(daily_pnl.get(d, 0) for d in sorted_dates[i:i+7])
            weekly_returns.append(week_pnl)
        
        avg_weekly = np.mean(weekly_returns) if weekly_returns else 0
        weekly_growth = (avg_weekly / self.initial_capital) * 100
        
        # Max drawdown
        peak = self.initial_capital
        max_dd = 0
        for pnl in [t.pnl for t in trades]:
            capital_check = peak + pnl
            if capital_check > peak:
                peak = capital_check
            dd = (peak - capital_check) / peak
            if dd > max_dd:
                max_dd = dd
        
        return {
            'initial_capital': self.initial_capital,
            'final_capital': capital,
            'total_profit': total_profit,
            'growth_percent': growth_percent,
            'total_trades': total_trades,
            'winning_trades': winning_trades,
            'losing_trades': losing_trades,
            'win_rate': win_rate,
            'profit_factor': profit_factor,
            'total_won': total_won,
            'total_lost': total_lost,
            'avg_win': total_won / winning_trades if winning_trades > 0 else 0,
            'avg_loss': total_lost / losing_trades if losing_trades > 0 else 0,
            'profitable_days': profitable_days,
            'losing_days': losing_days,
            'total_days': total_days,
            'daily_win_rate': daily_win_rate,
            'avg_weekly_return': avg_weekly,
            'weekly_growth': weekly_growth,
            'monthly_projection': weekly_growth * 4,
            'max_drawdown': max_dd * 100,
            'trades': trades,
            'daily_pnl': daily_pnl,
            'weekly_returns': weekly_returns
        }


def run_optimization():
    """Run multiple configurations to find optimal settings."""
    print("\n" + "="*80)
    print("🔬 OPTIMIZATION RUN - Testing Multiple Configurations")
    print("="*80)
    
    configs = [
        {'tp': 5, 'sl': 15, 'risk': 0.03, 'name': 'Conservative'},
        {'tp': 6, 'sl': 18, 'risk': 0.05, 'name': 'Moderate'},
        {'tp': 8, 'sl': 20, 'risk': 0.08, 'name': 'Aggressive'},
        {'tp': 10, 'sl': 25, 'risk': 0.10, 'name': 'Very Aggressive'},
    ]
    
    best_result = None
    best_config = None
    best_score = 0
    
    for cfg in configs:
        bt = OptimizedBacktest(initial_capital=50.0, leverage=500)
        bt.tp_pips = cfg['tp']
        bt.sl_pips = cfg['sl']
        bt.risk_per_trade = cfg['risk']
        
        result = bt.run_backtest(days=90)
        
        # Score based on growth and win rate
        score = result['growth_percent'] * (result['win_rate'] / 100)
        
        print(f"\n📊 {cfg['name']}: TP={cfg['tp']}p, SL={cfg['sl']}p, Risk={cfg['risk']*100}%")
        print(f"   Growth: {result['growth_percent']:.1f}% | Win Rate: {result['win_rate']:.1f}% | Score: {score:.1f}")
        
        if score > best_score:
            best_score = score
            best_result = result
            best_config = cfg
    
    return best_result, best_config


def main():
    """Main execution."""
    print("\n" + "="*80)
    print("🥇 GOLD TRADING BOT - OPTIMIZED BACKTEST REPORT")
    print("="*80)
    
    # Run optimization
    best_result, best_config = run_optimization()
    
    print("\n" + "="*80)
    print("🏆 OPTIMAL CONFIGURATION FOUND")
    print("="*80)
    
    result = best_result
    
    print(f"\n📊 TRADING CONFIGURATION:")
    print(f"   Take Profit: {best_config['tp']} pips")
    print(f"   Stop Loss: {best_config['sl']} pips")
    print(f"   Risk per Trade: {best_config['risk']*100}%")
    print(f"   Leverage: 1:500")
    print(f"   Partial Close: 50% at 4 pips profit")
    print(f"   Breakeven: After partial close")
    
    print(f"\n💰 ACCOUNT PERFORMANCE:")
    print(f"   Starting Capital: ${result['initial_capital']:.2f}")
    print(f"   Final Capital: ${result['final_capital']:.2f}")
    print(f"   Total Profit: ${result['total_profit']:.2f}")
    print(f"   Growth: {result['growth_percent']:.1f}%")
    
    print(f"\n📈 TRADING STATISTICS:")
    print(f"   Total Trades: {result['total_trades']}")
    print(f"   ✅ Winning Trades: {result['winning_trades']}")
    print(f"   ❌ Losing Trades: {result['losing_trades']}")
    print(f"   🎯 Win Rate: {result['win_rate']:.1f}%")
    print(f"   ⚖️ Profit Factor: {result['profit_factor']:.2f}")
    
    print(f"\n💵 TRADE ANALYSIS:")
    print(f"   Total Won: ${result['total_won']:.2f}")
    print(f"   Total Lost: ${result['total_lost']:.2f}")
    print(f"   Average Win: ${result['avg_win']:.2f}")
    print(f"   Average Loss: ${result['avg_loss']:.2f}")
    
    print(f"\n📅 DAILY PERFORMANCE:")
    print(f"   Profitable Days: {result['profitable_days']}/{result['total_days']}")
    print(f"   Losing Days: {result['losing_days']}")
    print(f"   Daily Win Rate: {result['daily_win_rate']:.1f}%")
    print(f"   Max Drawdown: {result['max_drawdown']:.1f}%")
    
    print(f"\n📊 GROWTH PROJECTIONS:")
    print(f"   Avg Weekly Return: ${result['avg_weekly_return']:.2f} ({result['weekly_growth']:.1f}%)")
    print(f"   Monthly Projection: {result['monthly_projection']:.1f}%")
    
    # Compounding projection
    print(f"\n🚀 COMPOUNDING GROWTH PROJECTION (12 weeks):")
    capital = 50.0
    weekly_rate = 1 + result['weekly_growth'] / 100
    for week in [1, 2, 4, 8, 12]:
        projected = 50.0 * (weekly_rate ** week)
        print(f"   Week {week:2d}: ${projected:.2f} ({(projected/50-1)*100:+.1f}%)")
    
    print("\n" + "="*80)
    print("✅ OPTIMIZED BACKTEST COMPLETE")
    print("="*80)
    
    return result


if __name__ == "__main__":
    main()
