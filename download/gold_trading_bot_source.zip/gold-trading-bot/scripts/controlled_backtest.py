#!/usr/bin/env python3
"""
CONTROLLED GOLD TRADING BACKTEST
Fixed position sizing to prevent unrealistic growth.
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import json
import os

# Configuration
CONFIG = {
    'INITIAL_CAPITAL': 50.0,
    'FIXED_LOT_SIZE': 0.01,   # Fixed lot size for small account
    'TP_PIPS': 8,             # Take profit in pips
    'SL_PIPS': 18,            # Stop loss in pips
    'PIP_VALUE': 0.10,        # $0.10 per pip for 0.01 lot gold
    'MAX_TRADES_PER_DAY': 3,
    'DAILY_LOSS_LIMIT_PCT': 0.05,
}


def calculate_indicators(df):
    """Calculate technical indicators."""
    df = df.copy()
    
    # EMAs
    for period in [9, 21, 50, 100]:
        df[f'ema_{period}'] = df['close'].ewm(span=period, adjust=False).mean()
    
    # RSI
    delta = df['close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
    rs = gain / loss.replace(0, 0.001)
    df['rsi'] = 100 - (100 / (1 + rs))
    
    # Stochastic
    low_min = df['low'].rolling(window=14).min()
    high_max = df['high'].rolling(window=14).max()
    range_val = high_max - low_min
    df['stoch_k'] = 100 * ((df['close'] - low_min) / range_val.replace(0, 0.001))
    
    # MACD
    exp12 = df['close'].ewm(span=12, adjust=False).mean()
    exp26 = df['close'].ewm(span=26, adjust=False).mean()
    df['macd'] = exp12 - exp26
    df['macd_hist'] = df['macd'] - df['macd'].ewm(span=9).mean()
    
    return df


def get_trend(df):
    """Get trend direction."""
    last = df.iloc[-1]
    
    bullish = last['ema_9'] > last['ema_21'] > last['ema_50']
    bearish = last['ema_9'] < last['ema_21'] < last['ema_50']
    
    if bullish:
        return 'BULLISH'
    elif bearish:
        return 'BEARISH'
    return 'NEUTRAL'


def check_entry(df, trend):
    """Check for high probability entry."""
    if trend == 'NEUTRAL':
        return False
    
    last = df.iloc[-1]
    prev = df.iloc[-2]
    score = 0
    
    if trend == 'BULLISH':
        if last['rsi'] < 40:
            score += 3
        elif last['rsi'] < 50:
            score += 2
        
        if last['stoch_k'] < 30:
            score += 3
        elif last['stoch_k'] < 40:
            score += 2
        
        if last['macd_hist'] > prev['macd_hist']:
            score += 2
    else:
        if last['rsi'] > 60:
            score += 3
        elif last['rsi'] > 50:
            score += 2
        
        if last['stoch_k'] > 70:
            score += 3
        elif last['stoch_k'] > 60:
            score += 2
        
        if last['macd_hist'] < prev['macd_hist']:
            score += 2
    
    return score >= 4


def run_backtest(initial_capital=50.0, days=90):
    """Run controlled backtest."""
    print(f"\n{'='*70}")
    print("  🎯 GOLD TRADING BACKTEST - CONTROLLED")
    print(f"{'='*70}")
    print(f"\n⚙️  Strategy:")
    print(f"   TP: {CONFIG['TP_PIPS']} pips = ${CONFIG['TP_PIPS'] * CONFIG['PIP_VALUE']:.2f}")
    print(f"   SL: {CONFIG['SL_PIPS']} pips = ${CONFIG['SL_PIPS'] * CONFIG['PIP_VALUE']:.2f}")
    print(f"   Fixed Lot: {CONFIG['FIXED_LOT_SIZE']}")
    print(f"   Capital: ${initial_capital}, Days: {days}")
    
    pip = 0.01
    
    # Generate realistic gold data
    np.random.seed(42)
    candles_per_day = 96
    total_candles = days * candles_per_day
    
    prices = []
    price = 2000.0
    
    for i in range(total_candles):
        trend = np.sin(i / 300) * 0.3 + np.sin(i / 100) * 0.15
        noise = np.random.normal(0, 1.0)
        jump = np.random.choice([0, 0, 0, 0, 0, -2, 2], 1)[0]
        price += trend + noise + jump
        price = max(1920, min(2080, price))
        prices.append(price)
    
    dates = pd.date_range(end=datetime.now(), periods=total_candles, freq='15min')
    df = pd.DataFrame({
        'open': prices,
        'close': [p + np.random.uniform(-0.2, 0.2) for p in prices],
        'high': [p + np.random.uniform(0.5, 1.5) for p in prices],
        'low': [p - np.random.uniform(0.5, 1.5) for p in prices],
        'volume': np.random.randint(500, 2000, total_candles)
    }, index=dates)
    
    df = calculate_indicators(df)
    
    # Trading simulation
    capital = initial_capital
    trades = []
    open_positions = []
    daily_pnl = {}
    daily_trades = {}
    
    tp_pips = CONFIG['TP_PIPS']
    sl_pips = CONFIG['SL_PIPS']
    pip_value = CONFIG['PIP_VALUE']
    lot_size = CONFIG['FIXED_LOT_SIZE']
    
    # Calculate P&L values
    tp_profit = tp_pips * pip_value  # Win amount
    sl_loss = sl_pips * pip_value    # Loss amount
    
    for i in range(50, len(df)):
        current_date = df.index[i].strftime('%Y-%m-%d')
        current_price = df['close'].iloc[i]
        
        if current_date not in daily_pnl:
            daily_pnl[current_date] = 0
            daily_trades[current_date] = 0
        
        # Manage open positions
        for pos in open_positions[:]:
            if pos['direction'] == 'BUY':
                # Check SL hit (price dropped)
                if current_price <= pos['sl']:
                    capital -= sl_loss
                    daily_pnl[current_date] -= sl_loss
                    trades.append({'direction': 'BUY', 'result': 'LOSS', 'pnl': -sl_loss, 
                                  'entry': pos['entry'], 'exit': pos['sl'], 'date': current_date})
                    open_positions.remove(pos)
                # Check TP hit (price rose)
                elif current_price >= pos['tp']:
                    capital += tp_profit
                    daily_pnl[current_date] += tp_profit
                    trades.append({'direction': 'BUY', 'result': 'WIN', 'pnl': tp_profit,
                                  'entry': pos['entry'], 'exit': pos['tp'], 'date': current_date})
                    open_positions.remove(pos)
            else:  # SELL
                # Check SL hit (price rose)
                if current_price >= pos['sl']:
                    capital -= sl_loss
                    daily_pnl[current_date] -= sl_loss
                    trades.append({'direction': 'SELL', 'result': 'LOSS', 'pnl': -sl_loss,
                                  'entry': pos['entry'], 'exit': pos['sl'], 'date': current_date})
                    open_positions.remove(pos)
                # Check TP hit (price dropped)
                elif current_price <= pos['tp']:
                    capital += tp_profit
                    daily_pnl[current_date] += tp_profit
                    trades.append({'direction': 'SELL', 'result': 'WIN', 'pnl': tp_profit,
                                  'entry': pos['entry'], 'exit': pos['tp'], 'date': current_date})
                    open_positions.remove(pos)
        
        # Daily loss limit
        if daily_pnl[current_date] < -capital * CONFIG['DAILY_LOSS_LIMIT_PCT']:
            continue
        
        # Max trades per day
        if daily_trades[current_date] >= CONFIG['MAX_TRADES_PER_DAY']:
            continue
        
        # Generate signals
        if len(open_positions) < 2:
            trend = get_trend(df.iloc[:i+1])
            
            if check_entry(df.iloc[:i+1], trend):
                last = df.iloc[i]
                entry = last['close']
                
                if trend == 'BULLISH':
                    sl = entry - (sl_pips * pip)
                    tp = entry + (tp_pips * pip)
                    direction = 'BUY'
                else:
                    sl = entry + (sl_pips * pip)
                    tp = entry - (tp_pips * pip)
                    direction = 'SELL'
                
                open_positions.append({
                    'entry': entry,
                    'sl': sl,
                    'tp': tp,
                    'direction': direction,
                    'time': str(df.index[i])
                })
                daily_trades[current_date] += 1
    
    # Close any remaining positions
    for pos in open_positions:
        capital -= sl_loss  # Assume loss for unclosed
        trades.append({'direction': pos['direction'], 'result': 'LOSS', 'pnl': -sl_loss})
    
    # Calculate results
    winning = [t for t in trades if t['pnl'] > 0]
    losing = [t for t in trades if t['pnl'] <= 0]
    
    total_profit = sum(t['pnl'] for t in trades)
    win_rate = len(winning) / len(trades) * 100 if trades else 0
    
    gross_profit = sum(t['pnl'] for t in winning)
    gross_loss = abs(sum(t['pnl'] for t in losing))
    profit_factor = gross_profit / gross_loss if gross_loss > 0 else float('inf')
    
    profitable_days = sum(1 for p in daily_pnl.values() if p > 0)
    total_days = len(daily_pnl)
    
    # Weekly
    weekly_returns = []
    dates_sorted = sorted(daily_pnl.keys())
    for i in range(0, len(dates_sorted), 7):
        week_pnl = sum(daily_pnl.get(d, 0) for d in dates_sorted[i:i+7])
        weekly_returns.append(week_pnl)
    
    results = {
        'initial_capital': initial_capital,
        'final_capital': round(capital, 2),
        'total_profit': round(total_profit, 2),
        'growth_percent': round((capital - initial_capital) / initial_capital * 100, 1),
        'total_trades': len(trades),
        'winning_trades': len(winning),
        'losing_trades': len(losing),
        'win_rate': round(win_rate, 1),
        'profit_factor': round(profit_factor, 2),
        'gross_profit': round(gross_profit, 2),
        'gross_loss': round(gross_loss, 2),
        'profitable_days': profitable_days,
        'total_days': total_days,
        'daily_win_rate': round(profitable_days / total_days * 100, 1) if total_days else 0,
        'avg_weekly_return': round(np.mean(weekly_returns), 2) if weekly_returns else 0,
        'best_day': round(max(daily_pnl.values()), 2),
        'worst_day': round(min(daily_pnl.values()), 2),
        'tp_pips': tp_pips,
        'sl_pips': sl_pips,
        'win_pnl': tp_profit,
        'loss_pnl': sl_loss,
    }
    
    # Print
    print(f"\n{'='*70}")
    print("  📈 BACKTEST RESULTS")
    print(f"{'='*70}")
    print(f"\n💰 Capital:")
    print(f"   Initial: ${initial_capital:.2f}")
    print(f"   Final:   ${capital:.2f}")
    print(f"   Profit:  ${total_profit:.2f}")
    print(f"   Growth:  {results['growth_percent']:.1f}%")
    
    print(f"\n📊 Trades:")
    print(f"   Total:    {len(trades)}")
    print(f"   Wins:     {len(winning)}")
    print(f"   Losses:   {len(losing)}")
    print(f"   Win Rate: {win_rate:.1f}%")
    print(f"   PF:       {profit_factor:.2f}")
    
    print(f"\n📅 Days:")
    print(f"   Profitable: {profitable_days}/{total_days}")
    print(f"   Win Rate:   {results['daily_win_rate']:.1f}%")
    print(f"   Best:       ${results['best_day']:.2f}")
    print(f"   Worst:      ${results['worst_day']:.2f}")
    
    print(f"\n{'='*70}\n")
    
    return results


if __name__ == "__main__":
    results = run_backtest(initial_capital=50.0, days=90)
    
    output_dir = '/home/z/my-project/download'
    os.makedirs(output_dir, exist_ok=True)
    
    with open(f'{output_dir}/backtest_results.json', 'w') as f:
        json.dump(results, f, indent=2)
    
    print(f"Saved: {output_dir}/backtest_results.json")
