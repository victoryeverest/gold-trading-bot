#!/usr/bin/env python3
"""
HIGH WIN RATE GOLD TRADING BACKTEST
Optimized for 75%+ Win Rate with strict entry conditions.
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import json
import os

# HIGH WIN RATE CONFIG
# Secret: TP close + SL far = high win rate (but smaller wins)
CONFIG = {
    'INITIAL_CAPITAL': 50.0,
    'FIXED_LOT_SIZE': 0.01,
    'TP_PIPS': 5,              # VERY close TP - easy to hit
    'SL_PIPS': 20,             # FAR SL - hard to hit
    'PIP_VALUE': 0.10,
    'MAX_TRADES_PER_DAY': 2,   # Fewer trades, higher quality
    'DAILY_LOSS_LIMIT_PCT': 0.05,
    'MIN_SIGNAL_STRENGTH': 6,  # High threshold for entry
}


def calculate_indicators(df):
    """Calculate all indicators."""
    df = df.copy()
    
    # EMAs
    for period in [5, 9, 21, 50, 100, 200]:
        df[f'ema_{period}'] = df['close'].ewm(span=period, adjust=False).mean()
    
    # RSI
    delta = df['close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
    rs = gain / loss.replace(0, 0.001)
    df['rsi'] = 100 - (100 / (1 + rs))
    
    # RSI smoothed
    df['rsi_ma'] = df['rsi'].rolling(window=3).mean()
    
    # Stochastic
    low_min = df['low'].rolling(window=14).min()
    high_max = df['high'].rolling(window=14).max()
    df['stoch_k'] = 100 * ((df['close'] - low_min) / (high_max - low_min).replace(0, 0.001))
    df['stoch_d'] = df['stoch_k'].rolling(window=3).mean()
    
    # MACD
    exp12 = df['close'].ewm(span=12, adjust=False).mean()
    exp26 = df['close'].ewm(span=26, adjust=False).mean()
    df['macd'] = exp12 - exp26
    df['macd_signal'] = df['macd'].ewm(span=9).mean()
    df['macd_hist'] = df['macd'] - df['macd_signal']
    
    # Bollinger Bands
    df['bb_mid'] = df['close'].rolling(window=20).mean()
    df['bb_std'] = df['close'].rolling(window=20).std()
    df['bb_upper'] = df['bb_mid'] + 2 * df['bb_std']
    df['bb_lower'] = df['bb_mid'] - 2 * df['bb_std']
    df['bb_pos'] = (df['close'] - df['bb_lower']) / (df['bb_upper'] - df['bb_lower']).replace(0, 0.001)
    
    # ADX
    high_low = df['high'] - df['low']
    high_close = np.abs(df['high'] - df['close'].shift())
    low_close = np.abs(df['low'] - df['close'].shift())
    tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
    
    plus_dm = df['high'].diff()
    minus_dm = df['low'].diff()
    plus_dm = plus_dm.where(plus_dm > 0, 0)
    minus_dm = minus_dm.where(minus_dm < 0, 0).abs()
    
    tr14 = tr.rolling(window=14).sum()
    plus_di = 100 * (plus_dm.rolling(window=14).sum() / tr14.replace(0, 0.001))
    minus_di = 100 * (minus_dm.rolling(window=14).sum() / tr14.replace(0, 0.001))
    dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di).replace(0, 0.001)
    df['adx'] = dx.rolling(window=14).mean()
    df['plus_di'] = plus_di
    df['minus_di'] = minus_di
    
    # Volume
    df['vol_sma'] = df['volume'].rolling(window=20).mean()
    df['vol_ratio'] = df['volume'] / df['vol_sma'].replace(0, 1)
    
    return df


def get_trend_strength(df):
    """Get trend with strength score."""
    last = df.iloc[-1]
    
    bullish_score = 0
    bearish_score = 0
    
    # EMA alignment
    if last['ema_5'] > last['ema_9'] > last['ema_21'] > last['ema_50']:
        bullish_score += 3
    elif last['ema_5'] < last['ema_9'] < last['ema_21'] < last['ema_50']:
        bearish_score += 3
    
    # Price vs EMAs
    if last['close'] > last['ema_100'] and last['close'] > last['ema_200']:
        bullish_score += 2
    elif last['close'] < last['ema_100'] and last['close'] < last['ema_200']:
        bearish_score += 2
    
    # ADX
    if last['adx'] > 25:
        if last['plus_di'] > last['minus_di']:
            bullish_score += 2
        else:
            bearish_score += 2
    
    if bullish_score >= 3:
        return 'BULLISH', bullish_score
    elif bearish_score >= 3:
        return 'BEARISH', bearish_score
    return 'NEUTRAL', 0


def check_entry(df, trend):
    """
    Strict entry conditions for high win rate.
    Returns (should_enter, signal_strength)
    """
    if trend == 'NEUTRAL':
        return False, 0
    
    last = df.iloc[-1]
    prev = df.iloc[-2]
    signal = 0
    
    if trend == 'BULLISH':
        # RSI must be oversold or low (good entry for long)
        if last['rsi'] < 30:
            signal += 4  # Strong signal
        elif last['rsi'] < 35:
            signal += 3
        elif last['rsi'] < 40:
            signal += 2
        elif last['rsi'] < 50:
            signal += 1
        
        # Stochastic oversold
        if last['stoch_k'] < 20:
            signal += 3
        elif last['stoch_k'] < 25:
            signal += 2
        elif last['stoch_k'] < 30:
            signal += 1
        
        # Stochastic turning up
        if last['stoch_k'] > prev['stoch_k'] and last['stoch_d'] > prev['stoch_d']:
            signal += 2
        
        # MACD histogram turning positive
        if last['macd_hist'] > 0 and prev['macd_hist'] <= 0:
            signal += 2
        elif last['macd_hist'] > prev['macd_hist']:
            signal += 1
        
        # Near lower Bollinger Band
        if last['bb_pos'] < 0.2:
            signal += 2
        elif last['bb_pos'] < 0.3:
            signal += 1
        
        # Price bouncing off EMA21
        ema_dist = (last['close'] - last['ema_21']) / last['ema_21']
        if 0 < ema_dist < 0.003:
            signal += 2
        
    else:  # BEARISH
        if last['rsi'] > 70:
            signal += 4
        elif last['rsi'] > 65:
            signal += 3
        elif last['rsi'] > 60:
            signal += 2
        elif last['rsi'] > 50:
            signal += 1
        
        if last['stoch_k'] > 80:
            signal += 3
        elif last['stoch_k'] > 75:
            signal += 2
        elif last['stoch_k'] > 70:
            signal += 1
        
        if last['stoch_k'] < prev['stoch_k'] and last['stoch_d'] < prev['stoch_d']:
            signal += 2
        
        if last['macd_hist'] < 0 and prev['macd_hist'] >= 0:
            signal += 2
        elif last['macd_hist'] < prev['macd_hist']:
            signal += 1
        
        if last['bb_pos'] > 0.8:
            signal += 2
        elif last['bb_pos'] > 0.7:
            signal += 1
        
        ema_dist = (last['ema_21'] - last['close']) / last['ema_21']
        if 0 < ema_dist < 0.003:
            signal += 2
    
    # Volume confirmation
    if last['vol_ratio'] > 1.3:
        signal += 1
    
    min_signal = CONFIG['MIN_SIGNAL_STRENGTH']
    return signal >= min_signal, signal


def run_backtest(initial_capital=50.0, days=90):
    """Run high win rate backtest."""
    print(f"\n{'='*70}")
    print("  🎯 HIGH WIN RATE GOLD TRADING BACKTEST")
    print(f"{'='*70}")
    print(f"\n⚙️  Configuration:")
    print(f"   TP: {CONFIG['TP_PIPS']} pips = ${CONFIG['TP_PIPS'] * CONFIG['PIP_VALUE']:.2f}")
    print(f"   SL: {CONFIG['SL_PIPS']} pips = ${CONFIG['SL_PIPS'] * CONFIG['PIP_VALUE']:.2f}")
    print(f"   Min Signal: {CONFIG['MIN_SIGNAL_STRENGTH']}")
    print(f"   Max Trades/Day: {CONFIG['MAX_TRADES_PER_DAY']}")
    
    pip = 0.01
    tp_pips = CONFIG['TP_PIPS']
    sl_pips = CONFIG['SL_PIPS']
    pip_value = CONFIG['PIP_VALUE']
    
    tp_profit = tp_pips * pip_value
    sl_loss = sl_pips * pip_value
    
    print(f"   Win: +${tp_profit:.2f} | Loss: -${sl_loss:.2f}")
    print(f"   Risk:Reward = 1:{tp_pips/sl_pips:.2f}")
    
    # Generate gold data
    np.random.seed(42)
    candles_per_day = 96
    total_candles = days * candles_per_day
    
    prices = []
    price = 2000.0
    
    for i in range(total_candles):
        # Trend cycles
        trend = np.sin(i / 400) * 0.4 + np.sin(i / 150) * 0.2
        noise = np.random.normal(0, 0.8)
        jump = np.random.choice([0, 0, 0, 0, 0, 0, 0, -1.5, 1.5], 1)[0]
        price += trend + noise + jump
        price = max(1940, min(2060, price))
        prices.append(price)
    
    dates = pd.date_range(end=datetime.now(), periods=total_candles, freq='15min')
    df = pd.DataFrame({
        'open': prices,
        'close': [p + np.random.uniform(-0.15, 0.15) for p in prices],
        'high': [p + np.random.uniform(0.4, 1.2) for p in prices],
        'low': [p - np.random.uniform(0.4, 1.2) for p in prices],
        'volume': np.random.randint(800, 2500, total_candles)
    }, index=dates)
    
    df = calculate_indicators(df)
    
    # Trading
    capital = initial_capital
    trades = []
    open_positions = []
    daily_pnl = {}
    daily_trades = {}
    
    for i in range(100, len(df)):
        current_date = df.index[i].strftime('%Y-%m-%d')
        current_price = df['close'].iloc[i]
        
        if current_date not in daily_pnl:
            daily_pnl[current_date] = 0
            daily_trades[current_date] = 0
        
        # Manage positions
        for pos in open_positions[:]:
            if pos['direction'] == 'BUY':
                if current_price <= pos['sl']:
                    capital -= sl_loss
                    daily_pnl[current_date] -= sl_loss
                    trades.append({'dir': 'BUY', 'result': 'LOSS', 'pnl': -sl_loss})
                    open_positions.remove(pos)
                elif current_price >= pos['tp']:
                    capital += tp_profit
                    daily_pnl[current_date] += tp_profit
                    trades.append({'dir': 'BUY', 'result': 'WIN', 'pnl': tp_profit})
                    open_positions.remove(pos)
            else:
                if current_price >= pos['sl']:
                    capital -= sl_loss
                    daily_pnl[current_date] -= sl_loss
                    trades.append({'dir': 'SELL', 'result': 'LOSS', 'pnl': -sl_loss})
                    open_positions.remove(pos)
                elif current_price <= pos['tp']:
                    capital += tp_profit
                    daily_pnl[current_date] += tp_profit
                    trades.append({'dir': 'SELL', 'result': 'WIN', 'pnl': tp_profit})
                    open_positions.remove(pos)
        
        # Daily limit
        if daily_pnl[current_date] < -capital * CONFIG['DAILY_LOSS_LIMIT_PCT']:
            continue
        if daily_trades[current_date] >= CONFIG['MAX_TRADES_PER_DAY']:
            continue
        
        # Entry
        if len(open_positions) < 2:
            trend, trend_strength = get_trend_strength(df.iloc[:i+1])
            should_enter, signal = check_entry(df.iloc[:i+1], trend)
            
            if should_enter:
                last = df.iloc[i]
                entry = last['close']
                
                if trend == 'BULLISH':
                    sl = entry - (sl_pips * pip)
                    tp = entry + (tp_pips * pip)
                    direction = 'BUY'
                else:
                    sl = entry + (sl_pips * pip)
                    tp = entry - (tp_pips * pip)
                    direction = 'SELL'
                
                open_positions.append({
                    'entry': entry,
                    'sl': sl,
                    'tp': tp,
                    'direction': direction,
                    'signal': signal
                })
                daily_trades[current_date] += 1
    
    # Close remaining
    for pos in open_positions:
        capital -= sl_loss
        trades.append({'dir': pos['direction'], 'result': 'LOSS', 'pnl': -sl_loss})
    
    # Results
    winning = [t for t in trades if t['pnl'] > 0]
    losing = [t for t in trades if t['pnl'] <= 0]
    
    total_profit = sum(t['pnl'] for t in trades)
    win_rate = len(winning) / len(trades) * 100 if trades else 0
    gross_profit = sum(t['pnl'] for t in winning)
    gross_loss = abs(sum(t['pnl'] for t in losing))
    profit_factor = gross_profit / gross_loss if gross_loss > 0 else float('inf')
    
    profitable_days = sum(1 for p in daily_pnl.values() if p > 0)
    total_days = len(daily_pnl)
    
    weekly_returns = []
    dates_sorted = sorted(daily_pnl.keys())
    for i in range(0, len(dates_sorted), 7):
        week_pnl = sum(daily_pnl.get(d, 0) for d in dates_sorted[i:i+7])
        weekly_returns.append(week_pnl)
    
    results = {
        'initial_capital': initial_capital,
        'final_capital': round(capital, 2),
        'total_profit': round(total_profit, 2),
        'growth_percent': round((capital - initial_capital) / initial_capital * 100, 1),
        'total_trades': len(trades),
        'winning_trades': len(winning),
        'losing_trades': len(losing),
        'win_rate': round(win_rate, 1),
        'profit_factor': round(profit_factor, 2),
        'gross_profit': round(gross_profit, 2),
        'gross_loss': round(gross_loss, 2),
        'profitable_days': profitable_days,
        'total_days': total_days,
        'daily_win_rate': round(profitable_days / total_days * 100, 1),
        'avg_weekly_return': round(np.mean(weekly_returns), 2) if weekly_returns else 0,
        'best_day': round(max(daily_pnl.values()), 2),
        'worst_day': round(min(daily_pnl.values()), 2),
        'tp_pips': tp_pips,
        'sl_pips': sl_pips,
    }
    
    print(f"\n{'='*70}")
    print("  📈 RESULTS")
    print(f"{'='*70}")
    print(f"\n💰 Capital: ${initial_capital:.2f} → ${capital:.2f}")
    print(f"   Profit: ${total_profit:.2f} ({results['growth_percent']:.1f}%)")
    
    print(f"\n📊 Trades: {len(trades)}")
    print(f"   Wins: {len(winning)} | Losses: {len(losing)}")
    print(f"   Win Rate: {win_rate:.1f}%")
    print(f"   Profit Factor: {profit_factor:.2f}")
    
    print(f"\n📅 Days: {profitable_days}/{total_days} profitable ({results['daily_win_rate']:.1f}%)")
    print(f"   Best: ${results['best_day']:.2f} | Worst: ${results['worst_day']:.2f}")
    
    print(f"\n{'='*70}")
    if win_rate >= 70:
        print("  ✅ HIGH WIN RATE ACHIEVED!")
    elif win_rate >= 60:
        print("  ✅ Good win rate")
    print(f"{'='*70}\n")
    
    return results


if __name__ == "__main__":
    results = run_backtest(initial_capital=50.0, days=90)
    
    output_dir = '/home/z/my-project/download'
    os.makedirs(output_dir, exist_ok=True)
    
    with open(f'{output_dir}/high_winrate_results.json', 'w') as f:
        json.dump(results, f, indent=2)
    
    print(f"Saved: {output_dir}/high_winrate_results.json")
