#!/usr/bin/env python3
"""
OPTIMIZED HIGH WIN RATE BACKTEST - CORRECTED
Properly calibrated P&L calculations for realistic results.
Target: 75%+ Win Rate with consistent profits.
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import json
import os

# OPTIMAL CONFIGURATION
# Key: Close TP + Far SL = Higher Win Rate
CONFIG = {
    'INITIAL_CAPITAL': 50.0,
    'TP_PIPS': 6,           # Close TP - easier to hit
    'SL_PIPS': 15,          # Far SL - harder to hit
    'PIP_VALUE': 0.10,      # $0.10 per pip for 0.01 lot
    'RISK_PER_TRADE': 0.02,  # 2% risk per trade
    'MAX_OPEN_TRADES': 2,
    'DAILY_LOSS_LIMIT': 0.05,
    'PARTIAL_CLOSE_PIPS': 4,
    'BREAKEVEN_PIPS': 3,
}


def calculate_indicators(df):
    """Calculate technical indicators."""
    df = df.copy()
    
    # EMAs
    for period in [9, 21, 50, 100, 200]:
        df[f'ema_{period}'] = df['close'].ewm(span=period, adjust=False).mean()
    
    # RSI
    delta = df['close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
    rs = gain / loss.replace(0, 0.001)
    df['rsi'] = 100 - (100 / (1 + rs))
    
    # MACD
    exp12 = df['close'].ewm(span=12, adjust=False).mean()
    exp26 = df['close'].ewm(span=26, adjust=False).mean()
    df['macd'] = exp12 - exp26
    df['macd_signal'] = df['macd'].ewm(span=9, adjust=False).mean()
    df['macd_hist'] = df['macd'] - df['macd_signal']
    
    # Stochastic
    low_min = df['low'].rolling(window=14).min()
    high_max = df['high'].rolling(window=14).max()
    range_val = high_max - low_min
    range_val = range_val.replace(0, 0.001)
    df['stoch_k'] = 100 * ((df['close'] - low_min) / range_val)
    df['stoch_d'] = df['stoch_k'].rolling(window=3).mean()
    
    # ADX
    high_low = df['high'] - df['low']
    high_close = np.abs(df['high'] - df['close'].shift())
    low_close = np.abs(df['low'] - df['close'].shift())
    true_range = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
    
    plus_dm = df['high'].diff()
    minus_dm = df['low'].diff()
    plus_dm = plus_dm.where(plus_dm > 0, 0)
    minus_dm = minus_dm.where(minus_dm < 0, 0).abs()
    
    tr14 = true_range.rolling(window=14).sum()
    plus_di = 100 * (plus_dm.rolling(window=14).sum() / tr14.replace(0, 0.001))
    minus_di = 100 * (minus_dm.rolling(window=14).sum() / tr14.replace(0, 0.001))
    di_sum = plus_di + minus_di
    di_sum = di_sum.replace(0, 0.001)
    dx = 100 * (plus_di - minus_di).abs() / di_sum
    df['adx'] = dx.rolling(window=14).mean()
    
    # Volume
    df['volume_sma'] = df['volume'].rolling(window=20).mean()
    df['volume_ratio'] = df['volume'] / df['volume_sma'].replace(0, 1)
    
    return df


def get_trend(df):
    """Determine trend direction."""
    last = df.iloc[-1]
    
    bullish = (last['ema_9'] > last['ema_21'] > last['ema_50'] and 
               last['close'] > last['ema_100'])
    bearish = (last['ema_9'] < last['ema_21'] < last['ema_50'] and 
               last['close'] < last['ema_100'])
    
    if bullish:
        return 'BULLISH'
    elif bearish:
        return 'BEARISH'
    return 'NEUTRAL'


def check_entry(df, trend):
    """Check for high probability entry."""
    if trend == 'NEUTRAL':
        return False, 0
    
    last = df.iloc[-1]
    prev = df.iloc[-2]
    score = 0
    
    if trend == 'BULLISH':
        # RSI conditions
        if last['rsi'] < 35:
            score += 3
        elif last['rsi'] < 45:
            score += 2
        elif last['rsi'] < 55:
            score += 1
        
        # Stochastic
        if last['stoch_k'] < 25:
            score += 3
        elif last['stoch_k'] < 35:
            score += 2
        
        # MACD histogram turning up
        if last['macd_hist'] > prev['macd_hist']:
            score += 2
        
        # Price position
        if last['close'] > last['ema_50']:
            score += 1
        
    else:  # BEARISH
        if last['rsi'] > 65:
            score += 3
        elif last['rsi'] > 55:
            score += 2
        elif last['rsi'] > 45:
            score += 1
        
        if last['stoch_k'] > 75:
            score += 3
        elif last['stoch_k'] > 65:
            score += 2
        
        if last['macd_hist'] < prev['macd_hist']:
            score += 2
        
        if last['close'] < last['ema_50']:
            score += 1
    
    # Volume confirmation
    if last['volume_ratio'] > 1.3:
        score += 1
    
    # ADX trend strength
    if last['adx'] > 25:
        score += 1
    
    return score >= 5, score


def run_optimized_backtest(initial_capital=50.0, days=90):
    """Run properly calibrated backtest."""
    print(f"\n{'='*70}")
    print("  🎯 OPTIMIZED HIGH WIN RATE BACKTEST")
    print(f"{'='*70}")
    print(f"\n⚙️  Strategy Configuration:")
    print(f"   TP: {CONFIG['TP_PIPS']} pips (close - easy to hit)")
    print(f"   SL: {CONFIG['SL_PIPS']} pips (far - harder to hit)")
    print(f"   Risk per trade: {CONFIG['RISK_PER_TRADE']*100}%")
    print(f"   Pip value: ${CONFIG['PIP_VALUE']} per pip (0.01 lot)")
    print(f"   Initial Capital: ${initial_capital}")
    print(f"   Period: {days} days")
    
    pip = 0.01  # Gold pip = $0.01 price movement
    
    # Generate realistic gold price data
    np.random.seed(42)
    candles_per_day = 96  # 15-minute candles
    total_candles = days * candles_per_day
    
    prices = []
    price = 2000.0
    
    for i in range(total_candles):
        # Multiple trend cycles
        trend = np.sin(i / 300) * 0.3 + np.sin(i / 100) * 0.15
        
        # Random noise
        noise = np.random.normal(0, 1.0)
        
        # Occasional jumps
        jump = np.random.choice([0, 0, 0, 0, 0, 0, 0, -2, 2], 1)[0]
        
        price += trend + noise + jump
        price = max(1920, min(2080, price))
        prices.append(price)
    
    # Create DataFrame
    dates = pd.date_range(end=datetime.now(), periods=total_candles, freq='15min')
    df = pd.DataFrame({
        'open': prices,
        'close': [p + np.random.uniform(-0.3, 0.3) for p in prices],
        'high': [p + np.random.uniform(0.5, 2.0) for p in prices],
        'low': [p - np.random.uniform(0.5, 2.0) for p in prices],
        'volume': np.random.randint(500, 2000, total_candles)
    }, index=dates)
    
    df = calculate_indicators(df)
    
    # Trading simulation
    capital = initial_capital
    trades = []
    open_positions = []
    daily_pnl = {}
    equity_curve = [{'date': 'start', 'capital': capital}]
    
    tp_pips = CONFIG['TP_PIPS']
    sl_pips = CONFIG['SL_PIPS']
    partial_pips = CONFIG['PARTIAL_CLOSE_PIPS']
    be_pips = CONFIG['BREAKEVEN_PIPS']
    pip_value = CONFIG['PIP_VALUE']
    
    for i in range(100, len(df)):
        current_date = df.index[i].strftime('%Y-%m-%d')
        current_price = df['close'].iloc[i]
        
        if current_date not in daily_pnl:
            daily_pnl[current_date] = 0
        
        # Manage open positions
        for pos in open_positions[:]:
            if pos['direction'] == 'BUY':
                profit_pips = (current_price - pos['entry']) / pip
                
                # Breakeven
                if not pos.get('be_set') and profit_pips >= be_pips:
                    pos['sl'] = pos['entry']
                    pos['be_set'] = True
                
                # Partial close
                if not pos.get('partial') and profit_pips >= partial_pips:
                    partial_pnl = profit_pips * pip_value * pos['size'] / 0.01 * 0.5
                    capital += partial_pnl
                    daily_pnl[current_date] += partial_pnl
                    pos['partial'] = True
                    pos['size'] *= 0.5
                
                # Check SL
                if current_price <= pos['sl']:
                    loss_pips = (pos['sl'] - pos['entry']) / pip
                    pnl = loss_pips * pip_value * pos['size'] / 0.01
                    pnl = -abs(pnl)  # Make sure it's negative
                    capital += pnl
                    daily_pnl[current_date] += pnl
                    trades.append({**pos, 'exit': pos['sl'], 'pnl': pnl, 
                                  'result': 'LOSS', 'exit_date': current_date})
                    open_positions.remove(pos)
                    
                # Check TP
                elif current_price >= pos['tp']:
                    win_pips = (pos['tp'] - pos['entry']) / pip
                    pnl = win_pips * pip_value * pos['size'] / 0.01
                    capital += pnl
                    daily_pnl[current_date] += pnl
                    trades.append({**pos, 'exit': pos['tp'], 'pnl': pnl, 
                                  'result': 'WIN', 'exit_date': current_date})
                    open_positions.remove(pos)
                    
            else:  # SELL
                profit_pips = (pos['entry'] - current_price) / pip
                
                if not pos.get('be_set') and profit_pips >= be_pips:
                    pos['sl'] = pos['entry']
                    pos['be_set'] = True
                
                if not pos.get('partial') and profit_pips >= partial_pips:
                    partial_pnl = profit_pips * pip_value * pos['size'] / 0.01 * 0.5
                    capital += partial_pnl
                    daily_pnl[current_date] += partial_pnl
                    pos['partial'] = True
                    pos['size'] *= 0.5
                
                if current_price >= pos['sl']:
                    loss_pips = (pos['entry'] - pos['sl']) / pip
                    pnl = loss_pips * pip_value * pos['size'] / 0.01
                    pnl = -abs(pnl)
                    capital += pnl
                    daily_pnl[current_date] += pnl
                    trades.append({**pos, 'exit': pos['sl'], 'pnl': pnl, 
                                  'result': 'LOSS', 'exit_date': current_date})
                    open_positions.remove(pos)
                    
                elif current_price <= pos['tp']:
                    win_pips = (pos['entry'] - pos['tp']) / pip
                    pnl = win_pips * pip_value * pos['size'] / 0.01
                    capital += pnl
                    daily_pnl[current_date] += pnl
                    trades.append({**pos, 'exit': pos['tp'], 'pnl': pnl, 
                                  'result': 'WIN', 'exit_date': current_date})
                    open_positions.remove(pos)
        
        # Record equity
        equity_curve.append({'date': current_date, 'capital': round(capital, 2)})
        
        # Daily loss limit check
        if daily_pnl[current_date] < -capital * CONFIG['DAILY_LOSS_LIMIT']:
            continue
        
        # Generate signals
        if len(open_positions) < CONFIG['MAX_OPEN_TRADES']:
            trend = get_trend(df.iloc[:i+1])
            valid, score = check_entry(df.iloc[:i+1], trend)
            
            if valid:
                last = df.iloc[i]
                entry = last['close']
                
                if trend == 'BULLISH':
                    sl = entry - (sl_pips * pip)
                    tp = entry + (tp_pips * pip)
                    direction = 'BUY'
                else:
                    sl = entry + (sl_pips * pip)
                    tp = entry - (tp_pips * pip)
                    direction = 'SELL'
                
                # Position sizing (risk-based)
                risk_amt = capital * CONFIG['RISK_PER_TRADE']
                # Risk = sl_pips * pip_value * lot_size / 0.01
                # lot_size = risk_amt / (sl_pips * pip_value) * 0.01
                lot_size = risk_amt / (sl_pips * pip_value) * 0.01
                lot_size = max(0.01, round(lot_size, 2))
                
                position = {
                    'entry': entry,
                    'sl': sl,
                    'tp': tp,
                    'size': lot_size,
                    'direction': direction,
                    'time': str(df.index[i]),
                    'score': score
                }
                open_positions.append(position)
    
    # Calculate final results
    winning = [t for t in trades if t['pnl'] > 0]
    losing = [t for t in trades if t['pnl'] <= 0]
    
    total_profit = sum(t['pnl'] for t in trades)
    win_rate = len(winning) / len(trades) * 100 if trades else 0
    
    gross_profit = sum(t['pnl'] for t in winning)
    gross_loss = abs(sum(t['pnl'] for t in losing))
    profit_factor = gross_profit / gross_loss if gross_loss > 0 else float('inf')
    
    profitable_days = sum(1 for p in daily_pnl.values() if p > 0)
    total_days = len(daily_pnl)
    daily_win_rate = profitable_days / total_days * 100 if total_days else 0
    
    # Weekly stats
    weekly_returns = []
    dates_sorted = sorted(daily_pnl.keys())
    for i in range(0, len(dates_sorted), 7):
        week_pnl = sum(daily_pnl.get(d, 0) for d in dates_sorted[i:i+7])
        weekly_returns.append(week_pnl)
    
    # Monthly stats
    monthly_returns = {}
    for date, pnl in daily_pnl.items():
        month = date[:7]
        if month not in monthly_returns:
            monthly_returns[month] = 0
        monthly_returns[month] += pnl
    
    results = {
        'initial_capital': initial_capital,
        'final_capital': round(capital, 2),
        'total_profit': round(total_profit, 2),
        'growth_percent': round((capital - initial_capital) / initial_capital * 100, 1),
        'total_trades': len(trades),
        'winning_trades': len(winning),
        'losing_trades': len(losing),
        'win_rate': round(win_rate, 1),
        'profit_factor': round(profit_factor, 2),
        'gross_profit': round(gross_profit, 2),
        'gross_loss': round(gross_loss, 2),
        'total_days': total_days,
        'profitable_days': profitable_days,
        'daily_win_rate': round(daily_win_rate, 1),
        'avg_weekly_return': round(np.mean(weekly_returns), 2) if weekly_returns else 0,
        'avg_trade_profit': round(np.mean([t['pnl'] for t in trades]), 2) if trades else 0,
        'best_day': round(max(daily_pnl.values()), 2) if daily_pnl else 0,
        'worst_day': round(min(daily_pnl.values()), 2) if daily_pnl else 0,
        'monthly_returns': {k: round(v, 2) for k, v in monthly_returns.items()},
        'winning_pips': sum((t['exit'] - t['entry'])/pip if t['direction']=='BUY' else (t['entry'] - t['exit'])/pip for t in winning),
    }
    
    # Print results
    print(f"\n{'='*70}")
    print("  📈 BACKTEST RESULTS")
    print(f"{'='*70}")
    print(f"\n💰 Capital Growth:")
    print(f"   Initial Capital:     ${initial_capital:.2f}")
    print(f"   Final Capital:       ${capital:.2f}")
    print(f"   Total Profit:        ${total_profit:.2f}")
    print(f"   Growth:              {results['growth_percent']:.1f}%")
    
    print(f"\n📊 Trade Statistics:")
    print(f"   Total Trades:        {len(trades)}")
    print(f"   Winning Trades:      {len(winning)}")
    print(f"   Losing Trades:       {len(losing)}")
    print(f"   Win Rate:            {win_rate:.1f}%")
    print(f"   Profit Factor:       {profit_factor:.2f}")
    print(f"   Avg Trade Profit:    ${results['avg_trade_profit']:.2f}")
    print(f"   Gross Profit:        ${gross_profit:.2f}")
    print(f"   Gross Loss:          ${gross_loss:.2f}")
    
    print(f"\n📅 Daily Performance:")
    print(f"   Total Days:          {total_days}")
    print(f"   Profitable Days:     {profitable_days}")
    print(f"   Daily Win Rate:      {daily_win_rate:.1f}%")
    print(f"   Best Day:            ${results['best_day']:.2f}")
    print(f"   Worst Day:           ${results['worst_day']:.2f}")
    
    print(f"\n📆 Weekly/Monthly:")
    print(f"   Avg Weekly Return:   ${results['avg_weekly_return']:.2f}")
    
    if monthly_returns:
        print(f"\n   Monthly Breakdown:")
        for month, pnl in sorted(monthly_returns.items()):
            print(f"     {month}: ${pnl:+.2f}")
    
    print(f"\n{'='*70}")
    
    if win_rate >= 70:
        print("  ✅ EXCELLENT WIN RATE ACHIEVED!")
    elif win_rate >= 60:
        print("  ✅ GOOD WIN RATE!")
    else:
        print(f"  📊 Win rate: {win_rate:.1f}%")
    
    print(f"{'='*70}\n")
    
    return results


if __name__ == "__main__":
    results = run_optimized_backtest(initial_capital=50.0, days=90)
    
    # Save results
    output_dir = '/home/z/my-project/download'
    os.makedirs(output_dir, exist_ok=True)
    
    with open(f'{output_dir}/optimized_backtest_results.json', 'w') as f:
        json.dump(results, f, indent=2)
    
    print(f"Results saved to {output_dir}/optimized_backtest_results.json")
