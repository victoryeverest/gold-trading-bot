#!/usr/bin/env python3
"""
OPTIMIZED BEST BACKTEST - Maximum Performance Configuration
This script runs the backtest with optimal parameters for best results.
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import json

# Optimal configuration for BEST results
OPTIMAL_CONFIG = {
    'TRADING_CONFIG': {
        'SYMBOL': 'XAUUSD',
        'INITIAL_CAPITAL': 50.0,
        
        # OPTIMIZED: Higher win rate with close TP, far SL
        'TAKE_PROFIT_ATR_MULT': 0.8,  # Closer TP for higher win rate
        'STOP_LOSS_ATR_MULT': 1.8,     # Farther SL to avoid being stopped out
        
        # Risk management
        'RISK_PER_TRADE': 0.02,        # Conservative risk
        'MAX_POSITION_SIZE': 0.08,     # Position sizing
        
        # Dynamic profit management
        'PARTIAL_CLOSE_AT_PROFIT_PERCENT': 0.4,  # Take partial profits early
        'TRAILING_STOP_TRIGGER': 0.3,
        'TRAILING_STOP_DISTANCE': 0.15,
        'BREAKEVEN_TRIGGER': 0.2,      # Move to BE early
        
        # Limits
        'MAX_OPEN_TRADES': 2,
        'DAILY_LOSS_LIMIT': 0.03,
        'MAX_DAILY_DRAWDOWN': 0.05,
        'DAILY_PROFIT_TARGET_PERCENT': 0.10,  # 10% daily target
    }
}


def calculate_indicators(df):
    """Calculate all technical indicators."""
    df = df.copy()
    
    # EMAs
    for period in [9, 21, 50, 100, 200]:
        df[f'ema_{period}'] = df['close'].ewm(span=period, adjust=False).mean()
    
    # RSI
    delta = df['close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
    rs = gain / loss
    df['rsi'] = 100 - (100 / (1 + rs))
    
    # ATR
    high_low = df['high'] - df['low']
    high_close = np.abs(df['high'] - df['close'].shift())
    low_close = np.abs(df['low'] - df['close'].shift())
    true_range = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
    df['atr'] = true_range.rolling(window=14).mean()
    
    # Bollinger Bands
    df['bb_middle'] = df['close'].rolling(window=20).mean()
    df['bb_std'] = df['close'].rolling(window=20).std()
    df['bb_upper'] = df['bb_middle'] + 2 * df['bb_std']
    df['bb_lower'] = df['bb_middle'] - 2 * df['bb_std']
    df['bb_position'] = (df['close'] - df['bb_lower']) / (df['bb_upper'] - df['bb_lower'])
    
    # MACD
    exp12 = df['close'].ewm(span=12, adjust=False).mean()
    exp26 = df['close'].ewm(span=26, adjust=False).mean()
    df['macd'] = exp12 - exp26
    df['macd_signal'] = df['macd'].ewm(span=9, adjust=False).mean()
    df['macd_hist'] = df['macd'] - df['macd_signal']
    
    # Stochastic
    low_min = df['low'].rolling(window=14).min()
    high_max = df['high'].rolling(window=14).max()
    df['stoch_k'] = 100 * ((df['close'] - low_min) / (high_max - low_min))
    df['stoch_d'] = df['stoch_k'].rolling(window=3).mean()
    
    # ADX
    plus_dm = df['high'].diff()
    minus_dm = df['low'].diff()
    plus_dm[plus_dm < 0] = 0
    minus_dm[minus_dm > 0] = 0
    tr14 = true_range.rolling(window=14).sum()
    plus_di = 100 * (plus_dm.rolling(window=14).sum() / tr14)
    minus_di = 100 * (abs(minus_dm).rolling(window=14).sum() / tr14)
    dx = 100 * abs(plus_di - minus_di) / (plus_di + minus_di)
    df['adx'] = dx.rolling(window=14).mean()
    
    # Volume
    df['volume_sma'] = df['volume'].rolling(window=20).mean()
    df['volume_ratio'] = df['volume'] / df['volume_sma']
    
    # Support/Resistance
    df['support'] = df['low'].rolling(window=20).min()
    df['resistance'] = df['high'].rolling(window=20).max()
    
    return df


def get_trend(df):
    """Get trend direction."""
    last = df.iloc[-1]
    
    ema_bullish = last['ema_9'] > last['ema_21'] > last['ema_50']
    ema_bearish = last['ema_9'] < last['ema_21'] < last['ema_50']
    
    if ema_bullish and last['close'] > last['ema_100']:
        return 'BULLISH', last['adx']
    elif ema_bearish and last['close'] < last['ema_100']:
        return 'BEARISH', last['adx']
    return 'NEUTRAL', last['adx']


def check_entry(df, trend):
    """Check for high probability entry."""
    last = df.iloc[-1]
    prev = df.iloc[-2]
    
    confidence = 0.0
    reasons = []
    
    if trend == 'NEUTRAL':
        return False, '', 0
    
    # RSI conditions
    if trend == 'BULLISH':
        if last['rsi'] < 35:
            confidence += 0.20
            reasons.append('RSI oversold')
        elif last['rsi'] < 45:
            confidence += 0.15
            reasons.append('RSI favorable')
    else:
        if last['rsi'] > 65:
            confidence += 0.20
            reasons.append('RSI overbought')
        elif last['rsi'] > 55:
            confidence += 0.15
            reasons.append('RSI favorable')
    
    # EMA crossover
    if trend == 'BULLISH' and prev['ema_9'] <= prev['ema_21'] and last['ema_9'] > last['ema_21']:
        confidence += 0.25
        reasons.append('EMA crossover')
    elif trend == 'BEARISH' and prev['ema_9'] >= prev['ema_21'] and last['ema_9'] < last['ema_21']:
        confidence += 0.25
        reasons.append('EMA crossover')
    
    # MACD
    if last['macd_hist'] > 0 and prev['macd_hist'] <= 0:
        confidence += 0.15
        reasons.append('MACD positive')
    elif last['macd_hist'] < 0 and prev['macd_hist'] >= 0:
        confidence += 0.15
        reasons.append('MACD negative')
    
    # Bollinger
    if trend == 'BULLISH' and last['bb_position'] < 0.25:
        confidence += 0.10
        reasons.append('Near lower BB')
    elif trend == 'BEARISH' and last['bb_position'] > 0.75:
        confidence += 0.10
        reasons.append('Near upper BB')
    
    # Stochastic
    if trend == 'BULLISH' and last['stoch_k'] < 25:
        confidence += 0.10
        reasons.append('Stoch oversold')
    elif trend == 'BEARISH' and last['stoch_k'] > 75:
        confidence += 0.10
        reasons.append('Stoch overbought')
    
    # Volume
    if last['volume_ratio'] > 1.3:
        confidence += 0.10
        reasons.append('High volume')
    
    if confidence >= 0.40:
        return True, '; '.join(reasons), min(confidence, 1.0)
    return False, '', confidence


def run_optimized_backtest(initial_capital=50.0, days=90):
    """Run optimized backtest."""
    print(f"\n{'='*70}")
    print("  OPTIMIZED GOLD TRADING BACKTEST - Best Performance Configuration")
    print(f"{'='*70}")
    print(f"\n📊 Configuration:")
    print(f"   Initial Capital: ${initial_capital}")
    print(f"   Backtest Period: {days} days")
    print(f"   TP Multiplier: 0.8 ATR (close for high win rate)")
    print(f"   SL Multiplier: 1.8 ATR (far to avoid stops)")
    print(f"   Partial Close: 40% profit target")
    print(f"   Breakeven Trigger: 20% profit")
    
    config = OPTIMAL_CONFIG['TRADING_CONFIG']
    
    # Generate realistic data
    np.random.seed(42)
    candles_per_day = 96  # 15-min candles
    total_candles = days * candles_per_day
    
    # Generate with realistic gold patterns
    prices = []
    price = 2000.0
    trend = 0.0
    
    for i in range(total_candles):
        # Multiple trend cycles
        trend = np.sin(i / 300) * 0.3 + np.sin(i / 100) * 0.1
        
        # Volatility clustering
        vol = np.random.normal(0, 1.5)
        if len(prices) > 0:
            recent_vol = abs(prices[-1] - prices[-2]) if len(prices) > 1 else 0
            if recent_vol > 3:
                vol *= 1.5
        
        # Random jumps (news events)
        jump = np.random.choice([0, 0, 0, 0, 0, 0, -3, 3], 1)[0]
        
        price += trend + vol + jump
        price = max(1850, min(2150, price))
        prices.append(price)
    
    # Create DataFrame
    dates = pd.date_range(end=datetime.now(), periods=total_candles, freq='15min')
    df = pd.DataFrame({
        'open': prices,
        'close': [p + np.random.uniform(-0.5, 0.5) for p in prices],
        'high': [p + np.random.uniform(1, 4) for p in prices],
        'low': [p - np.random.uniform(1, 4) for p in prices],
        'volume': np.random.randint(200, 3000, total_candles)
    }, index=dates)
    
    # Calculate indicators
    df = calculate_indicators(df)
    
    # Trading simulation
    capital = initial_capital
    trades = []
    open_positions = []
    daily_pnl = {}
    equity_curve = []
    
    tp_mult = config['TAKE_PROFIT_ATR_MULT']
    sl_mult = config['STOP_LOSS_ATR_MULT']
    partial_close_at = config['PARTIAL_CLOSE_AT_PROFIT_PERCENT']
    breakeven_trigger = config['BREAKEVEN_TRIGGER']
    
    atr_col = df['atr'].fillna(df['close'].diff().abs().rolling(14).mean())
    
    for i in range(100, len(df)):
        current_date = df.index[i].strftime('%Y-%m-%d')
        current_price = df['close'].iloc[i]
        atr = atr_col.iloc[i]
        
        if current_date not in daily_pnl:
            daily_pnl[current_date] = 0
        
        # Record equity
        equity_curve.append({
            'date': current_date,
            'time': df.index[i],
            'capital': capital
        })
        
        # Manage positions
        for pos in open_positions[:]:
            # Calculate profit
            if pos['direction'] == 'BUY':
                profit_pips = (current_price - pos['entry']) / 0.01
                
                # Check breakeven
                if not pos.get('be_set') and profit_pips > pos['tp_pips'] * breakeven_trigger:
                    pos['sl'] = pos['entry']
                    pos['be_set'] = True
                
                # Check partial close
                if not pos.get('partial') and profit_pips > pos['tp_pips'] * partial_close_at:
                    partial_pnl = profit_pips * 0.1 * pos['size'] * 0.5
                    capital += partial_pnl
                    daily_pnl[current_date] += partial_pnl
                    pos['partial'] = True
                    pos['size'] *= 0.5
                
                # Check exits
                if current_price <= pos['sl']:
                    pnl = (pos['sl'] - pos['entry']) / 0.01 * 0.1 * pos['size']
                    capital += pnl
                    daily_pnl[current_date] += pnl
                    trades.append({**pos, 'exit': pos['sl'], 'pnl': pnl, 'result': 'LOSS', 'exit_date': current_date})
                    open_positions.remove(pos)
                elif current_price >= pos['tp']:
                    pnl = (pos['tp'] - pos['entry']) / 0.01 * 0.1 * pos['size']
                    capital += pnl
                    daily_pnl[current_date] += pnl
                    trades.append({**pos, 'exit': pos['tp'], 'pnl': pnl, 'result': 'WIN', 'exit_date': current_date})
                    open_positions.remove(pos)
            else:  # SELL
                profit_pips = (pos['entry'] - current_price) / 0.01
                
                if not pos.get('be_set') and profit_pips > pos['tp_pips'] * breakeven_trigger:
                    pos['sl'] = pos['entry']
                    pos['be_set'] = True
                
                if not pos.get('partial') and profit_pips > pos['tp_pips'] * partial_close_at:
                    partial_pnl = profit_pips * 0.1 * pos['size'] * 0.5
                    capital += partial_pnl
                    daily_pnl[current_date] += partial_pnl
                    pos['partial'] = True
                    pos['size'] *= 0.5
                
                if current_price >= pos['sl']:
                    pnl = (pos['entry'] - pos['sl']) / 0.01 * 0.1 * pos['size']
                    capital += pnl
                    daily_pnl[current_date] += pnl
                    trades.append({**pos, 'exit': pos['sl'], 'pnl': pnl, 'result': 'LOSS', 'exit_date': current_date})
                    open_positions.remove(pos)
                elif current_price <= pos['tp']:
                    pnl = (pos['entry'] - pos['tp']) / 0.01 * 0.1 * pos['size']
                    capital += pnl
                    daily_pnl[current_date] += pnl
                    trades.append({**pos, 'exit': pos['tp'], 'pnl': pnl, 'result': 'WIN', 'exit_date': current_date})
                    open_positions.remove(pos)
        
        # Check daily loss limit
        if daily_pnl[current_date] < -capital * config['DAILY_LOSS_LIMIT']:
            continue
        
        # Generate signals
        if len(open_positions) < config['MAX_OPEN_TRADES']:
            trend_dir, adx = get_trend(df.iloc[:i+1])
            
            if adx > 20:  # Only trade with trend
                valid, reason, confidence = check_entry(df.iloc[:i+1], trend_dir)
                
                if valid and confidence >= 0.40:
                    last = df.iloc[i]
                    atr_val = atr_col.iloc[i]
                    
                    if trend_dir == 'BULLISH':
                        entry = last['close']
                        sl = entry - (atr_val * sl_mult)
                        tp = entry + (atr_val * tp_mult)
                        direction = 'BUY'
                    else:
                        entry = last['close']
                        sl = entry + (atr_val * sl_mult)
                        tp = entry - (atr_val * tp_mult)
                        direction = 'SELL'
                    
                    # Position sizing
                    risk_amt = capital * config['RISK_PER_TRADE']
                    sl_pips = abs(entry - sl) / 0.01
                    size = max(0.01, round(risk_amt / (sl_pips * 0.1), 2))
                    tp_pips = abs(tp - entry) / 0.01
                    
                    position = {
                        'entry': entry,
                        'sl': sl,
                        'tp': tp,
                        'tp_pips': tp_pips,
                        'size': size,
                        'direction': direction,
                        'time': df.index[i],
                        'confidence': confidence,
                        'reason': reason
                    }
                    open_positions.append(position)
    
    # Calculate results
    winning = [t for t in trades if t['pnl'] > 0]
    losing = [t for t in trades if t['pnl'] <= 0]
    
    total_profit = sum(t['pnl'] for t in trades)
    win_rate = len(winning) / len(trades) * 100 if trades else 0
    profit_factor = (sum(t['pnl'] for t in winning) / abs(sum(t['pnl'] for t in losing))) if losing else float('inf')
    
    # Daily stats
    profitable_days = sum(1 for p in daily_pnl.values() if p > 0)
    total_days = len(daily_pnl)
    daily_win_rate = profitable_days / total_days * 100 if total_days else 0
    
    # Weekly stats
    weekly_returns = []
    dates_sorted = sorted(daily_pnl.keys())
    for i in range(0, len(dates_sorted), 7):
        week_pnl = sum(daily_pnl.get(d, 0) for d in dates_sorted[i:i+7])
        weekly_returns.append(week_pnl)
    
    # Monthly stats
    monthly_returns = {}
    for date, pnl in daily_pnl.items():
        month = date[:7]
        if month not in monthly_returns:
            monthly_returns[month] = 0
        monthly_returns[month] += pnl
    
    results = {
        'initial_capital': initial_capital,
        'final_capital': capital,
        'total_profit': total_profit,
        'growth_percent': (capital - initial_capital) / initial_capital * 100,
        'total_trades': len(trades),
        'winning_trades': len(winning),
        'losing_trades': len(losing),
        'win_rate': win_rate,
        'profit_factor': profit_factor,
        'total_days': total_days,
        'profitable_days': profitable_days,
        'daily_win_rate': daily_win_rate,
        'avg_weekly_return': np.mean(weekly_returns) if weekly_returns else 0,
        'avg_trade_profit': np.mean([t['pnl'] for t in trades]) if trades else 0,
        'max_drawdown': min(daily_pnl.values()) if daily_pnl else 0,
        'best_day': max(daily_pnl.values()) if daily_pnl else 0,
        'worst_day': min(daily_pnl.values()) if daily_pnl else 0,
        'monthly_returns': monthly_returns,
        'weekly_returns': weekly_returns,
        'daily_pnl': daily_pnl,
        'trades': trades,
        'equity_curve': equity_curve
    }
    
    # Print results
    print(f"\n{'='*70}")
    print("  📈 BACKTEST RESULTS")
    print(f"{'='*70}")
    print(f"\n💰 Capital Growth:")
    print(f"   Initial Capital:     ${initial_capital:.2f}")
    print(f"   Final Capital:       ${capital:.2f}")
    print(f"   Total Profit:        ${total_profit:.2f}")
    print(f"   Growth:              {results['growth_percent']:.1f}%")
    
    print(f"\n📊 Trade Statistics:")
    print(f"   Total Trades:        {len(trades)}")
    print(f"   Winning Trades:      {len(winning)}")
    print(f"   Losing Trades:       {len(losing)}")
    print(f"   Win Rate:            {win_rate:.1f}%")
    print(f"   Profit Factor:       {profit_factor:.2f}")
    print(f"   Avg Trade Profit:    ${results['avg_trade_profit']:.2f}")
    
    print(f"\n📅 Daily Performance:")
    print(f"   Total Days:          {total_days}")
    print(f"   Profitable Days:     {profitable_days}")
    print(f"   Daily Win Rate:      {daily_win_rate:.1f}%")
    print(f"   Best Day:            ${results['best_day']:.2f}")
    print(f"   Worst Day:           ${results['worst_day']:.2f}")
    
    print(f"\n📆 Weekly/Monthly:")
    print(f"   Avg Weekly Return:   ${results['avg_weekly_return']:.2f}")
    print(f"   Weekly Trades:       {len(weekly_returns)} weeks")
    
    if monthly_returns:
        print(f"\n   Monthly Breakdown:")
        for month, pnl in sorted(monthly_returns.items()):
            print(f"     {month}: ${pnl:+.2f}")
    
    print(f"\n{'='*70}")
    print("  ✅ BACKTEST COMPLETE")
    print(f"{'='*70}\n")
    
    return results


if __name__ == "__main__":
    results = run_optimized_backtest(initial_capital=50.0, days=90)
    
    # Save results
    output_dir = '/home/z/my-project/download'
    os.makedirs(output_dir, exist_ok=True)
    
    # Save summary
    summary = {
        'initial_capital': results['initial_capital'],
        'final_capital': results['final_capital'],
        'total_profit': results['total_profit'],
        'growth_percent': results['growth_percent'],
        'total_trades': results['total_trades'],
        'winning_trades': results['winning_trades'],
        'losing_trades': results['losing_trades'],
        'win_rate': results['win_rate'],
        'profit_factor': results['profit_factor'],
        'daily_win_rate': results['daily_win_rate'],
        'avg_weekly_return': results['avg_weekly_return']
    }
    
    with open(f'{output_dir}/backtest_results.json', 'w') as f:
        json.dump(summary, f, indent=2)
    
    print(f"\nResults saved to {output_dir}/backtest_results.json")
