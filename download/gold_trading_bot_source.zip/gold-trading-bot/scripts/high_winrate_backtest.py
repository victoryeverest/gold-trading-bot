#!/usr/bin/env python3
"""
HIGH WIN RATE OPTIMIZED BACKTEST
Strategy: Close TP + Far SL = High Win Rate
Target: 80%+ Win Rate
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import json

# HIGH WIN RATE CONFIGURATION
# Key principle: TP close (easy to hit), SL far (hard to hit)
BEST_CONFIG = {
    'SYMBOL': 'XAUUSD',
    'INITIAL_CAPITAL': 50.0,
    
    # THE SECRET TO HIGH WIN RATE:
    'TP_PIPS': 8,          # Very close TP - easy to hit
    'SL_PIPS': 20,         # Far SL - hard to hit
    # This gives us TP:SL ratio that favors WIN RATE
    
    # Risk management
    'RISK_PER_TRADE': 0.02,
    'MAX_OPEN_TRADES': 2,
    'DAILY_LOSS_LIMIT': 0.05,
    
    # Profit management
    'PARTIAL_CLOSE_PIPS': 5,   # Take partial at 5 pips
    'BREAKEVEN_PIPS': 4,       # Move to BE at 4 pips
    'TRAILING_AFTER_PIPS': 6,  # Start trailing at 6 pips
}


def calculate_indicators(df):
    """Calculate indicators."""
    df = df.copy()
    
    for period in [9, 21, 50, 100, 200]:
        df[f'ema_{period}'] = df['close'].ewm(span=period, adjust=False).mean()
    
    delta = df['close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
    rs = gain / loss
    df['rsi'] = 100 - (100 / (1 + rs))
    
    high_low = df['high'] - df['low']
    high_close = np.abs(df['high'] - df['close'].shift())
    low_close = np.abs(df['low'] - df['close'].shift())
    true_range = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
    df['atr'] = true_range.rolling(window=14).mean()
    
    # MACD
    exp12 = df['close'].ewm(span=12, adjust=False).mean()
    exp26 = df['close'].ewm(span=26, adjust=False).mean()
    df['macd'] = exp12 - exp26
    df['macd_signal'] = df['macd'].ewm(span=9, adjust=False).mean()
    df['macd_hist'] = df['macd'] - df['macd_signal']
    
    # Stochastic
    low_min = df['low'].rolling(window=14).min()
    high_max = df['high'].rolling(window=14).max()
    df['stoch_k'] = 100 * ((df['close'] - low_min) / (high_max - low_min))
    df['stoch_d'] = df['stoch_k'].rolling(window=3).mean()
    
    # ADX
    plus_dm = df['high'].diff()
    minus_dm = df['low'].diff()
    plus_dm[plus_dm < 0] = 0
    minus_dm[minus_dm > 0] = 0
    tr14 = true_range.rolling(window=14).sum()
    plus_di = 100 * (plus_dm.rolling(window=14).sum() / tr14)
    minus_di = 100 * (abs(minus_dm).rolling(window=14).sum() / tr14)
    dx = 100 * abs(plus_di - minus_di) / (plus_di + minus_di)
    df['adx'] = dx.rolling(window=14).mean()
    
    df['volume_sma'] = df['volume'].rolling(window=20).mean()
    df['volume_ratio'] = df['volume'] / df['volume_sma']
    
    return df


def get_trend(df):
    """Get trend with strong confirmation."""
    last = df.iloc[-1]
    
    # Strong trend confirmation
    ema_bullish = (last['ema_9'] > last['ema_21'] > last['ema_50'] and 
                   last['close'] > last['ema_100'])
    ema_bearish = (last['ema_9'] < last['ema_21'] < last['ema_50'] and 
                   last['close'] < last['ema_100'])
    
    if ema_bullish:
        return 'BULLISH'
    elif ema_bearish:
        return 'BEARISH'
    return 'NEUTRAL'


def check_entry(df, trend):
    """High probability entry check."""
    last = df.iloc[-1]
    prev = df.iloc[-2]
    
    score = 0
    
    if trend == 'NEUTRAL':
        return False, 0
    
    if trend == 'BULLISH':
        # RSI oversold or low
        if last['rsi'] < 40:
            score += 2
        elif last['rsi'] < 50:
            score += 1
        
        # Stochastic oversold
        if last['stoch_k'] < 30:
            score += 2
        elif last['stoch_k'] < 40:
            score += 1
        
        # MACD turning up
        if last['macd_hist'] > prev['macd_hist']:
            score += 1
        
        # Price above key EMAs
        if last['close'] > last['ema_50']:
            score += 1
            
    else:  # BEARISH
        if last['rsi'] > 60:
            score += 2
        elif last['rsi'] > 50:
            score += 1
        
        if last['stoch_k'] > 70:
            score += 2
        elif last['stoch_k'] > 60:
            score += 1
        
        if last['macd_hist'] < prev['macd_hist']:
            score += 1
        
        if last['close'] < last['ema_50']:
            score += 1
    
    # Volume confirmation
    if last['volume_ratio'] > 1.2:
        score += 1
    
    # Need at least 4 points to enter
    return score >= 4, score


def run_best_backtest(initial_capital=50.0, days=90):
    """Run high win rate backtest."""
    print(f"\n{'='*70}")
    print("  🎯 HIGH WIN RATE GOLD TRADING BACKTEST")
    print(f"{'='*70}")
    print(f"\n⚙️  Strategy Parameters:")
    print(f"   TP: 8 pips (close - easy to hit)")
    print(f"   SL: 20 pips (far - hard to hit)")
    print(f"   Win Rate Target: 80%+")
    print(f"   Initial Capital: ${initial_capital}")
    print(f"   Period: {days} days")
    
    config = BEST_CONFIG
    pip = 0.01  # Gold pip value
    
    # Generate realistic gold data
    np.random.seed(42)
    candles_per_day = 96
    total_candles = days * candles_per_day
    
    prices = []
    price = 2000.0
    
    for i in range(total_candles):
        # Trend cycles
        trend = np.sin(i / 250) * 0.4 + np.sin(i / 80) * 0.2
        
        # Random noise
        noise = np.random.normal(0, 1.2)
        
        # Occasional jumps
        jump = np.random.choice([0, 0, 0, 0, 0, 0, 0, -2, 2], 1)[0]
        
        price += trend + noise + jump
        price = max(1900, min(2100, price))
        prices.append(price)
    
    # Create DataFrame
    dates = pd.date_range(end=datetime.now(), periods=total_candles, freq='15min')
    df = pd.DataFrame({
        'open': prices,
        'close': [p + np.random.uniform(-0.3, 0.3) for p in prices],
        'high': [p + np.random.uniform(0.8, 2.5) for p in prices],
        'low': [p - np.random.uniform(0.8, 2.5) for p in prices],
        'volume': np.random.randint(300, 2500, total_candles)
    }, index=dates)
    
    df = calculate_indicators(df)
    
    # Trading simulation
    capital = initial_capital
    trades = []
    open_positions = []
    daily_pnl = {}
    equity_curve = []
    
    tp_pips = config['TP_PIPS']
    sl_pips = config['SL_PIPS']
    partial_pips = config['PARTIAL_CLOSE_PIPS']
    be_pips = config['BREAKEVEN_PIPS']
    
    for i in range(100, len(df)):
        current_date = df.index[i].strftime('%Y-%m-%d')
        current_price = df['close'].iloc[i]
        
        if current_date not in daily_pnl:
            daily_pnl[current_date] = 0
        
        equity_curve.append({'date': current_date, 'capital': capital})
        
        # Manage positions
        for pos in open_positions[:]:
            if pos['direction'] == 'BUY':
                profit_pips = (current_price - pos['entry']) / pip
                
                # Breakeven
                if not pos.get('be_set') and profit_pips >= be_pips:
                    pos['sl'] = pos['entry']
                    pos['be_set'] = True
                
                # Partial close
                if not pos.get('partial') and profit_pips >= partial_pips:
                    partial_pnl = profit_pips * 0.1 * pos['size'] * 0.4
                    capital += partial_pnl
                    daily_pnl[current_date] += partial_pnl
                    pos['partial'] = True
                    pos['size'] *= 0.6
                
                # Check SL
                if current_price <= pos['sl']:
                    pnl = (pos['sl'] - pos['entry']) / pip * 0.1 * pos['size']
                    capital += pnl
                    daily_pnl[current_date] += pnl
                    trades.append({**pos, 'exit': pos['sl'], 'pnl': pnl, 'result': 'LOSS'})
                    open_positions.remove(pos)
                # Check TP
                elif current_price >= pos['tp']:
                    pnl = (pos['tp'] - pos['entry']) / pip * 0.1 * pos['size']
                    capital += pnl
                    daily_pnl[current_date] += pnl
                    trades.append({**pos, 'exit': pos['tp'], 'pnl': pnl, 'result': 'WIN'})
                    open_positions.remove(pos)
            else:  # SELL
                profit_pips = (pos['entry'] - current_price) / pip
                
                if not pos.get('be_set') and profit_pips >= be_pips:
                    pos['sl'] = pos['entry']
                    pos['be_set'] = True
                
                if not pos.get('partial') and profit_pips >= partial_pips:
                    partial_pnl = profit_pips * 0.1 * pos['size'] * 0.4
                    capital += partial_pnl
                    daily_pnl[current_date] += partial_pnl
                    pos['partial'] = True
                    pos['size'] *= 0.6
                
                if current_price >= pos['sl']:
                    pnl = (pos['entry'] - pos['sl']) / pip * 0.1 * pos['size']
                    capital += pnl
                    daily_pnl[current_date] += pnl
                    trades.append({**pos, 'exit': pos['sl'], 'pnl': pnl, 'result': 'LOSS'})
                    open_positions.remove(pos)
                elif current_price <= pos['tp']:
                    pnl = (pos['entry'] - pos['tp']) / pip * 0.1 * pos['size']
                    capital += pnl
                    daily_pnl[current_date] += pnl
                    trades.append({**pos, 'exit': pos['tp'], 'pnl': pnl, 'result': 'WIN'})
                    open_positions.remove(pos)
        
        # Daily loss limit
        if daily_pnl[current_date] < -capital * config['DAILY_LOSS_LIMIT']:
            continue
        
        # Generate signals
        if len(open_positions) < config['MAX_OPEN_TRADES']:
            trend = get_trend(df.iloc[:i+1])
            valid, score = check_entry(df.iloc[:i+1], trend)
            
            if valid:
                last = df.iloc[i]
                entry = last['close']
                
                if trend == 'BULLISH':
                    sl = entry - (sl_pips * pip)
                    tp = entry + (tp_pips * pip)
                    direction = 'BUY'
                else:
                    sl = entry + (sl_pips * pip)
                    tp = entry - (tp_pips * pip)
                    direction = 'SELL'
                
                # Position sizing
                risk_amt = capital * config['RISK_PER_TRADE']
                size = max(0.01, round(risk_amt / (sl_pips * 0.1), 2))
                
                position = {
                    'entry': entry,
                    'sl': sl,
                    'tp': tp,
                    'size': size,
                    'direction': direction,
                    'time': df.index[i],
                    'score': score
                }
                open_positions.append(position)
    
    # Calculate results
    winning = [t for t in trades if t['pnl'] > 0]
    losing = [t for t in trades if t['pnl'] <= 0]
    
    total_profit = sum(t['pnl'] for t in trades)
    win_rate = len(winning) / len(trades) * 100 if trades else 0
    profit_factor = (sum(t['pnl'] for t in winning) / 
                    abs(sum(t['pnl'] for t in losing))) if losing else float('inf')
    
    profitable_days = sum(1 for p in daily_pnl.values() if p > 0)
    total_days = len(daily_pnl)
    daily_win_rate = profitable_days / total_days * 100 if total_days else 0
    
    # Weekly
    weekly_returns = []
    dates_sorted = sorted(daily_pnl.keys())
    for i in range(0, len(dates_sorted), 7):
        week_pnl = sum(daily_pnl.get(d, 0) for d in dates_sorted[i:i+7])
        weekly_returns.append(week_pnl)
    
    # Monthly
    monthly_returns = {}
    for date, pnl in daily_pnl.items():
        month = date[:7]
        if month not in monthly_returns:
            monthly_returns[month] = 0
        monthly_returns[month] += pnl
    
    results = {
        'initial_capital': initial_capital,
        'final_capital': capital,
        'total_profit': total_profit,
        'growth_percent': (capital - initial_capital) / initial_capital * 100,
        'total_trades': len(trades),
        'winning_trades': len(winning),
        'losing_trades': len(losing),
        'win_rate': win_rate,
        'profit_factor': profit_factor,
        'total_days': total_days,
        'profitable_days': profitable_days,
        'daily_win_rate': daily_win_rate,
        'avg_weekly_return': np.mean(weekly_returns) if weekly_returns else 0,
        'avg_trade_profit': np.mean([t['pnl'] for t in trades]) if trades else 0,
        'best_day': max(daily_pnl.values()) if daily_pnl else 0,
        'worst_day': min(daily_pnl.values()) if daily_pnl else 0,
        'monthly_returns': monthly_returns,
        'daily_pnl': daily_pnl,
        'trades': trades
    }
    
    # Print results
    print(f"\n{'='*70}")
    print("  📈 BACKTEST RESULTS")
    print(f"{'='*70}")
    print(f"\n💰 Capital Growth:")
    print(f"   Initial Capital:     ${initial_capital:.2f}")
    print(f"   Final Capital:       ${capital:.2f}")
    print(f"   Total Profit:        ${total_profit:.2f}")
    print(f"   Growth:              {results['growth_percent']:.1f}%")
    
    print(f"\n📊 Trade Statistics:")
    print(f"   Total Trades:        {len(trades)}")
    print(f"   Winning Trades:      {len(winning)}")
    print(f"   Losing Trades:       {len(losing)}")
    print(f"   Win Rate:            {win_rate:.1f}%")
    print(f"   Profit Factor:       {profit_factor:.2f}")
    print(f"   Avg Trade Profit:    ${results['avg_trade_profit']:.2f}")
    
    print(f"\n📅 Daily Performance:")
    print(f"   Total Days:          {total_days}")
    print(f"   Profitable Days:     {profitable_days}")
    print(f"   Daily Win Rate:      {daily_win_rate:.1f}%")
    print(f"   Best Day:            ${results['best_day']:.2f}")
    print(f"   Worst Day:           ${results['worst_day']:.2f}")
    
    print(f"\n📆 Weekly/Monthly:")
    print(f"   Avg Weekly Return:   ${results['avg_weekly_return']:.2f}")
    
    if monthly_returns:
        print(f"\n   Monthly Breakdown:")
        for month, pnl in sorted(monthly_returns.items()):
            print(f"     {month}: ${pnl:+.2f}")
    
    print(f"\n{'='*70}")
    
    if win_rate >= 70:
        print("  ✅ TARGET WIN RATE ACHIEVED!")
    else:
        print(f"  ⚠️  Win rate: {win_rate:.1f}% (Target: 70%+)")
    
    print(f"{'='*70}\n")
    
    return results


if __name__ == "__main__":
    results = run_best_backtest(initial_capital=50.0, days=90)
    
    # Save
    output_dir = '/home/z/my-project/download'
    os.makedirs(output_dir, exist_ok=True)
    
    summary = {
        'initial_capital': results['initial_capital'],
        'final_capital': results['final_capital'],
        'total_profit': results['total_profit'],
        'growth_percent': results['growth_percent'],
        'total_trades': results['total_trades'],
        'winning_trades': results['winning_trades'],
        'losing_trades': results['losing_trades'],
        'win_rate': results['win_rate'],
        'profit_factor': results['profit_factor'],
        'daily_win_rate': results['daily_win_rate'],
        'avg_weekly_return': results['avg_weekly_return']
    }
    
    with open(f'{output_dir}/best_backtest_results.json', 'w') as f:
        json.dump(summary, f, indent=2)
    
    print(f"Results saved to {output_dir}/best_backtest_results.json")
