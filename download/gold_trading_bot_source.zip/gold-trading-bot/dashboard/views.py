"""
Dashboard Views
Main views for the trading dashboard with authentication
"""

from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.views.decorators.http import require_POST
from django.utils import timezone
from django.db import models
from django.db.models import Sum, Count, Avg, Q
from datetime import datetime, timedelta
import json
import random

from core.models import UserProfile, Trade, DailyStats, BotLog, Signal


# ============ Authentication Views ============

def register_view(request):
    """User registration view."""
    if request.user.is_authenticated:
        return redirect('dashboard:home')
        
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            # Create user profile
            UserProfile.objects.get_or_create(user=user)
            login(request, user)
            return redirect('dashboard:home')
    else:
        form = UserCreationForm()
    
    return render(request, 'dashboard/register.html', {'form': form})


def login_view(request):
    """User login view."""
    if request.user.is_authenticated:
        return redirect('dashboard:home')
        
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            next_url = request.GET.get('next', 'dashboard:home')
            return redirect(next_url)
    else:
        form = AuthenticationForm()
    
    return render(request, 'dashboard/login.html', {'form': form})


@login_required
def logout_view(request):
    """User logout view."""
    logout(request)
    return redirect('dashboard:login')


# ============ Dashboard Views ============

@login_required
def dashboard_home(request):
    """Main dashboard home view."""
    user = request.user
    profile, created = UserProfile.objects.get_or_create(user=user)
    
    # Get trading statistics
    trades = Trade.objects.filter(user=user)
    total_trades = trades.count()
    winning_trades = trades.filter(pnl__gt=0).count()
    losing_trades = trades.filter(pnl__lt=0).count()
    
    total_pnl = trades.aggregate(total=Sum('pnl'))['total'] or 0
    win_rate = (winning_trades / total_trades * 100) if total_trades > 0 else 0
    
    # Get recent trades
    recent_trades = trades[:10]
    
    # Get recent signals
    recent_signals = Signal.objects.all()[:5]
    
    # Get daily stats for chart (last 30 days)
    end_date = timezone.now().date()
    start_date = end_date - timedelta(days=30)
    daily_stats = DailyStats.objects.filter(
        user=user,
        date__gte=start_date
    ).order_by('date')
    
    # Calculate growth
    initial = float(profile.initial_capital)
    current = initial + float(total_pnl)
    growth_percent = ((current - initial) / initial * 100) if initial > 0 else 0
    
    # Prepare chart data
    chart_dates = [stat.date.strftime('%Y-%m-%d') for stat in daily_stats]
    chart_balances = [float(stat.ending_balance) for stat in daily_stats]
    
    context = {
        'profile': profile,
        'total_trades': total_trades,
        'winning_trades': winning_trades,
        'losing_trades': losing_trades,
        'total_pnl': total_pnl,
        'win_rate': round(win_rate, 1),
        'current_balance': round(current, 2),
        'growth_percent': round(growth_percent, 1),
        'recent_trades': recent_trades,
        'recent_signals': recent_signals,
        'chart_dates': json.dumps(chart_dates),
        'chart_balances': json.dumps(chart_balances),
        'trading_enabled': profile.trading_enabled,
    }
    
    return render(request, 'dashboard/home.html', context)


@login_required
def trades_view(request):
    """Trade history view."""
    user = request.user
    
    # Filter options
    status = request.GET.get('status', '')
    direction = request.GET.get('direction', '')
    
    trades = Trade.objects.filter(user=user)
    
    if status:
        trades = trades.filter(status=status)
    if direction:
        trades = trades.filter(direction=direction)
    
    # Calculate totals
    total_pnl = trades.aggregate(total=Sum('pnl'))['total'] or 0
    total_trades = trades.count()
    winning_trades = trades.filter(pnl__gt=0).count()
    
    context = {
        'trades': trades,
        'status_filter': status,
        'direction_filter': direction,
        'total_pnl': total_pnl,
        'total_trades': total_trades,
        'winning_trades': winning_trades,
        'win_rate': round((winning_trades / total_trades * 100) if total_trades > 0 else 0, 1),
    }
    
    return render(request, 'dashboard/trades.html', context)


@login_required
def analytics_view(request):
    """Analytics and charts view."""
    user = request.user
    
    # Get daily stats for the last 30 days
    end_date = timezone.now().date()
    start_date = end_date - timedelta(days=30)
    
    daily_stats = DailyStats.objects.filter(
        user=user,
        date__gte=start_date,
        date__lte=end_date
    ).order_by('date')
    
    # Prepare chart data
    dates = [stat.date.strftime('%Y-%m-%d') for stat in daily_stats]
    balances = [float(stat.ending_balance) for stat in daily_stats]
    pnls = [float(stat.total_pnl) for stat in daily_stats]
    
    # Performance by day of week
    weekday_stats = _trades_by_weekday(user)
    
    # Performance by hour
    hourly_stats = _trades_by_hour(user)
    
    # Strategy performance
    strategy_stats = _trades_by_strategy(user)
    
    context = {
        'dates': json.dumps(dates),
        'balances': json.dumps(balances),
        'pnls': json.dumps(pnls),
        'weekday_stats': weekday_stats,
        'hourly_stats': hourly_stats,
        'strategy_stats': strategy_stats,
    }
    
    return render(request, 'dashboard/analytics.html', context)


def _trades_by_weekday(user):
    """Get trade performance by day of week."""
    trades = Trade.objects.filter(user=user, status='CLOSED')
    
    weekdays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
    stats = {i: {'trades': 0, 'wins': 0, 'pnl': 0} for i in range(7)}
    
    for trade in trades:
        day = trade.opened_at.weekday()
        stats[day]['trades'] += 1
        if trade.pnl > 0:
            stats[day]['wins'] += 1
        stats[day]['pnl'] += float(trade.pnl)
    
    result = []
    for i, day_name in enumerate(weekdays):
        result.append({
            'day': day_name,
            'trades': stats[i]['trades'],
            'wins': stats[i]['wins'],
            'win_rate': round((stats[i]['wins'] / stats[i]['trades'] * 100) if stats[i]['trades'] > 0 else 0, 1),
            'pnl': round(stats[i]['pnl'], 2)
        })
    
    return result


def _trades_by_hour(user):
    """Get trade performance by hour of day."""
    trades = Trade.objects.filter(user=user, status='CLOSED')
    
    stats = {i: {'trades': 0, 'wins': 0} for i in range(24)}
    
    for trade in trades:
        hour = trade.opened_at.hour
        stats[hour]['trades'] += 1
        if trade.pnl > 0:
            stats[hour]['wins'] += 1
    
    result = []
    for i in range(24):
        result.append({
            'hour': f'{i:02d}:00',
            'trades': stats[i]['trades'],
            'wins': stats[i]['wins'],
            'win_rate': round((stats[i]['wins'] / stats[i]['trades'] * 100) if stats[i]['trades'] > 0 else 0, 1)
        })
    
    return result


def _trades_by_strategy(user):
    """Get trade performance by strategy."""
    trades = Trade.objects.filter(user=user, status='CLOSED')
    
    strategies = trades.values('strategy').annotate(
        total_trades=Count('id'),
        total_pnl=Sum('pnl'),
        avg_pnl=Avg('pnl'),
        wins=Count('id', filter=Q(pnl__gt=0))
    )
    
    result = []
    for s in strategies:
        result.append({
            'strategy': s['strategy'],
            'total_trades': s['total_trades'],
            'total_pnl': round(float(s['total_pnl'] or 0), 2),
            'avg_pnl': round(float(s['avg_pnl'] or 0), 2),
            'wins': s['wins'],
            'win_rate': round((s['wins'] / s['total_trades'] * 100) if s['total_trades'] > 0 else 0, 1)
        })
    
    return result


@login_required
def settings_view(request):
    """User settings view."""
    user = request.user
    profile, created = UserProfile.objects.get_or_create(user=user)
    
    if request.method == 'POST':
        # Update profile
        profile.initial_capital = request.POST.get('initial_capital', profile.initial_capital)
        profile.risk_per_trade = request.POST.get('risk_per_trade', profile.risk_per_trade)
        profile.max_open_trades = request.POST.get('max_open_trades', profile.max_open_trades)
        profile.mt5_login = request.POST.get('mt5_login', profile.mt5_login or '')
        profile.mt5_server = request.POST.get('mt5_server', profile.mt5_server)
        profile.telegram_chat_id = request.POST.get('telegram_chat_id', profile.telegram_chat_id or '')
        profile.telegram_alerts = request.POST.get('telegram_alerts') == 'on'
        profile.save()
        
        return redirect('dashboard:settings')
    
    context = {
        'profile': profile,
    }
    
    return render(request, 'dashboard/settings.html', context)


@login_required
def bot_control_view(request):
    """Bot control panel view."""
    user = request.user
    profile, created = UserProfile.objects.get_or_create(user=user)
    
    # Get recent logs
    logs = BotLog.objects.all()[:50]
    
    # Get active signals
    signals = Signal.objects.filter(executed=False)[:10]
    
    context = {
        'profile': profile,
        'logs': logs,
        'signals': signals,
        'trading_enabled': profile.trading_enabled,
    }
    
    return render(request, 'dashboard/bot_control.html', context)


# ============ API Views ============

@login_required
@require_POST
def toggle_bot(request):
    """Toggle bot on/off."""
    user = request.user
    profile = UserProfile.objects.get(user=user)
    
    profile.trading_enabled = not profile.trading_enabled
    profile.save()
    
    # Log the action
    BotLog.objects.create(
        user=user,
        level='INFO' if profile.trading_enabled else 'WARNING',
        message=f"Bot {'started' if profile.trading_enabled else 'stopped'} by {user.username}"
    )
    
    return JsonResponse({
        'success': True,
        'trading_enabled': profile.trading_enabled,
        'message': f"Bot {'started' if profile.trading_enabled else 'stopped'}"
    })


@login_required
def get_stats(request):
    """Get current trading statistics as JSON."""
    user = request.user
    
    trades = Trade.objects.filter(user=user)
    total_trades = trades.count()
    winning_trades = trades.filter(pnl__gt=0).count()
    total_pnl = trades.aggregate(total=Sum('pnl'))['total'] or 0
    
    profile = UserProfile.objects.get(user=user)
    current_balance = float(profile.initial_capital) + float(total_pnl)
    
    return JsonResponse({
        'total_trades': total_trades,
        'winning_trades': winning_trades,
        'losing_trades': total_trades - winning_trades,
        'win_rate': round((winning_trades / total_trades * 100) if total_trades > 0 else 0, 1),
        'total_pnl': float(total_pnl),
        'current_balance': round(current_balance, 2),
        'growth_percent': round(((current_balance - float(profile.initial_capital)) / float(profile.initial_capital) * 100), 1)
    })


@login_required
def get_chart_data(request):
    """Get chart data for dashboard."""
    user = request.user
    days = int(request.GET.get('days', 30))
    
    end_date = timezone.now().date()
    start_date = end_date - timedelta(days=days)
    
    daily_stats = DailyStats.objects.filter(
        user=user,
        date__gte=start_date,
        date__lte=end_date
    ).order_by('date')
    
    data = {
        'dates': [stat.date.strftime('%Y-%m-%d') for stat in daily_stats],
        'balances': [float(stat.ending_balance) for stat in daily_stats],
        'pnls': [float(stat.total_pnl) for stat in daily_stats],
        'win_rates': [float(stat.win_rate) for stat in daily_stats],
    }
    
    return JsonResponse(data)


@login_required
def get_recent_signals(request):
    """Get recent trading signals."""
    signals = Signal.objects.all()[:10]
    
    data = [{
        'id': s.id,
        'symbol': s.symbol,
        'direction': s.direction,
        'entry': float(s.entry_price),
        'sl': float(s.stop_loss),
        'tp': float(s.take_profit),
        'confidence': float(s.confidence),
        'executed': s.executed,
        'result': s.result,
        'created_at': s.created_at.isoformat()
    } for s in signals]
    
    return JsonResponse({'signals': data})


@login_required
def get_market_data(request):
    """Get current market data."""
    # In production, this would fetch from MT5 or API
    # For demo, return simulated data
    
    base_price = 2000
    change = random.uniform(-20, 20)
    
    data = {
        'symbol': 'XAUUSD',
        'bid': round(base_price + change - 0.5, 2),
        'ask': round(base_price + change + 0.5, 2),
        'spread': 1.0,
        'change': round(change, 2),
        'change_percent': round((change / base_price) * 100, 2),
        'high_24h': round(base_price + abs(change) + 10, 2),
        'low_24h': round(base_price - abs(change) - 10, 2),
        'timestamp': timezone.now().isoformat()
    }
    
    return JsonResponse(data)
