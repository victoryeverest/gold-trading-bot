"""
Dashboard URL Configuration
"""

from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

app_name = 'dashboard'

urlpatterns = [
    # Authentication
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    
    # Main views
    path('', views.dashboard_home, name='home'),
    path('trades/', views.trades_view, name='trades'),
    path('analytics/', views.analytics_view, name='analytics'),
    path('settings/', views.settings_view, name='settings'),
    path('bot/', views.bot_control_view, name='bot_control'),
    
    # API endpoints
    path('api/toggle-bot/', views.toggle_bot, name='toggle_bot'),
    path('api/stats/', views.get_stats, name='api_stats'),
    path('api/chart-data/', views.get_chart_data, name='chart_data'),
    path('api/signals/', views.get_recent_signals, name='api_signals'),
    path('api/market/', views.get_market_data, name='api_market'),
]
