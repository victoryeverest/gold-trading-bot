"""
Core Admin Configuration
"""

from django.contrib import admin
from .models import UserProfile, Trade, DailyStats, BotLog, Signal


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'initial_capital', 'risk_per_trade', 'trading_enabled')
    list_filter = ('trading_enabled',)
    search_fields = ('user__username',)


@admin.register(Trade)
class TradeAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'symbol', 'direction', 'status', 'entry_price', 'pnl', 'opened_at')
    list_filter = ('direction', 'status', 'symbol')
    search_fields = ('user__username', 'symbol')
    date_hierarchy = 'opened_at'
    ordering = ('-opened_at',)


@admin.register(DailyStats)
class DailyStatsAdmin(admin.ModelAdmin):
    list_display = ('user', 'date', 'total_trades', 'winning_trades', 'total_pnl', 'win_rate')
    list_filter = ('date',)
    date_hierarchy = 'date'


@admin.register(BotLog)
class BotLogAdmin(admin.ModelAdmin):
    list_display = ('timestamp', 'level', 'user', 'message')
    list_filter = ('level',)
    search_fields = ('message',)
    date_hierarchy = 'timestamp'
    readonly_fields = ('timestamp',)


@admin.register(Signal)
class SignalAdmin(admin.ModelAdmin):
    list_display = ('created_at', 'symbol', 'direction', 'entry_price', 'confidence', 'executed', 'result')
    list_filter = ('direction', 'executed', 'result')
    date_hierarchy = 'created_at'
